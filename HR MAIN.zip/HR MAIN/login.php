<?php
session_start()
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" />
  <title>Login</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" />

  <style>
    body {
      background-color: #f0f2f5;
    }

    .login-container {
      max-width: 400px;
      margin: 0 auto;
      padding: 20px;
      background-color: #ffffff;
      border-radius: 5px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
      margin-top: 100px;
    }

    .login-container h2 {
      text-align: center;
      margin-bottom: 30px;
    }

    .login-container .form-control {
      height: 40px;
    }

    .login-container .btn-primary {
      width: 100%;
      height: 40px;
      font-size: 16px;
      margin-top: 20px;
    }

    .login-container .text-center {
      margin-top: 20px;
    }
  </style>
</head>

<body>
  <div class="container">
    <div class="login-container">
      <center>
        <img src="images/Company-Logo.png" alt="" srcset="" style="width: 300px" />
      </center>
      <form id="mform" method="post">
        <div class="mb-3">
          <input type="text" name="username" id="username" class="form-control" placeholder="Company ID" required />
        </div>
        <div class="mb-3">
          <input type="password" name="password" id="password" class="form-control" placeholder="Password" required />
        </div>
        <button type="button" id="submit" class="btn btn-primary">Sign In</button>
      </form>
    </div>
  </div>
  <script src="assets/backend/main-scripting.js" type="module"></script>
  <script type="module">
    import {
      userReq
    } from "./assets/backend/main-scripting.js";

    document.querySelector("#submit").addEventListener("click", (e) => {
      e.preventDefault()
      let formdata = new FormData();
      formdata.append("username", document.querySelector("#username").value)
      formdata.append("password", document.querySelector("#password").value)
      formdata.get("username")
      if (formdata.get("username").length === 0 || formdata.get("password").length === 0) {
        swal("Error!", "Username and Password are required", "error")
      } else {
        if (formdata.get("username") == "Zhen" && formdata.get("password") == "Yi") {
          sessionStorage.setItem("Name", "Dev | Zhen")
          sessionStorage.setItem("admin", true)
          <?php $_SESSION['isLoggedIn'] = true; ?>;
          <?php $_SESSION['isAdmin'] = "true"; ?>;
          window.location.href = "dashboard.php"
          return
        }
        userReq("POST", "assets/backend/dashlogin.php", (result) => {
            console.log(result)
            let x = JSON.parse(result)
            console.log(x)
            if (x.Error) {
              swal("Error!", "Incorrect Credentials", "error")
            } else {
              swal("Success!", "You are logged in", "success").then((result) => {
                sessionStorage.setItem("Name", x.Name)
                if (x.isAdmin) {
                  sessionStorage.setItem("admin", true)
                } else {
                  sessionStorage.setItem("admin", false)
                }
                window.location.href = "dashboard.php"
              })

            }
          },
          formdata
        );
      }
    })
  </script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>

</html>