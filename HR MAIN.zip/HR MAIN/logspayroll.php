<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <style>
      * {
        margin: 0;
        padding: 0;
      }
      body {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        width: 100%;
      }
      h1 {
        font-size: 80px;
      }
      img {
        width: 200px;
      }
    </style>
  </head>
  <body>
    <h1>PAYROLL LOGS</h1>
    <img src="images/logo.png" alt="" />
    <h1>UNDER DEVELOPMENT</h1>
  </body>
</html>
