<?php
session_start();
?>
<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>NEO CORE | LOGIN</title>
  <link rel="stylesheet" type="text/css" href="assets/css/style/style.css" />
  <style>
    .inputBorder {
      border-color: red;
    }
  </style>
</head>

<body>
  <div class="container" style="height: 700px;">
    <div class="bluebg">
      <div class="box signin">
        <p style="position: center; left: 25%; top: 24px">
          <img src="images/Company-Logo.png" alt="" height="200" width="400" />
        </p>
        <h2>NEO CORE</h2>
        <br />
        <h2>Already Have An Account?</h2>
        <button class="signinBtn">Sign In</button>
      </div>
      <div class="box signup">
        <p style="position: center; left: 25%; top: 24px">
          <img src="images/Company-Logo.png" alt="" height="200" width="400" />
        </p>
        <h2>NEO CORE</h2>
        <br />
        <h2>Don't Have An Account?</h2>
        <button class="signupBtn">Sign Up</button>
      </div>
    </div>
    <div class="formbx">
      <div class="form signinForm">
        <form id="signin">
          <h3>Sign In</h3>
          <input type="text" name="email" placeholder="Email" />
          <input type="password" name="password" placeholder="Password" />
          <div class="g-recaptcha" data-sitekey="6Leap7YlAAAAAICeHJmIHQTMDJhwq0byLjvSYP34" id="mcaptcha_log"></div>
          <input type="submit" id="login" value="Login" />
          <a href="#" class="forgot">Forgot Password?</a>
        </form>
      </div>
      <div class="form signupForm">
        <form id="singup">
          <h3>Sign Up</h3>
          <input type="text" placeholder="Firstname" name="fname" required />
          <input type="text" placeholder="Middlename" name="mname" required />
          <input type="text" placeholder="Lastname" name="lname" required />
          <input type="date" name="birthday" required />
          <select name="gender" id="gender">
            <option value="" hidden>Select gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
          <input type="text" class="inputBorder" name="email" id="email" placeholder="Email Address" required />
          <input type="password" placeholder="Password" name="pass" required />
          <input type="password" placeholder="Confirm Password" name="copass" required />
          <div class="g-recaptcha" data-sitekey="6LewibYlAAAAAFkSseB4fQt3pEmTT0rUxBTXn9GN" id="mcaptcha_reg"></div>
          <input type="submit" id="register" value="Register" />
        </form>
      </div>
    </div>
  </div>

  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
  <script src="assets/backend/main-scripting.js" type="module"></script>
  <script type="module">
    import {
      codeReq
    } from "./assets/backend/main-scripting.js"
    const signinBtn = document.querySelector(".signinBtn");
    const signupBtn = document.querySelector(".signupBtn");
    const formbx = document.querySelector(".formbx");
    const body = document.querySelector("body");
    document.querySelector("#register").style.display = "block"
    signupBtn.onclick = function() {
      formbx.classList.add("active");
      body.classList.add("active");
    };

    signinBtn.onclick = function() {
      formbx.classList.remove("active");
      body.classList.remove("active");
    };
    // 1 6LewibYlAAAAAFkSseB4fQt3pEmTT0rUxBTXn9GN
    // 2 6Leap7YlAAAAAICeHJmIHQTMDJhwq0byLjvSYP34
    let logWidget = grecaptcha.render("mcaptcha_log", {
      'sitekey': "6Leap7YlAAAAAICeHJmIHQTMDJhwq0byLjvSYP34"
    });
    let regWidget = grecaptcha.render("mcaptcha_reg", {
      'sitekey': "6LewibYlAAAAAFkSseB4fQt3pEmTT0rUxBTXn9GN"
    });
    document.querySelector("#login").addEventListener("click", (e) => {
      e.preventDefault()
      let response = grecaptcha.getResponse(logWidget);
      if (response == '') {
        swal("You forgot something", "Please fill the captcha", "error");
      } else {
        let data = new FormData(document.querySelector("#signin"))
        let userdata = {
          email: data.get("email"),
          pass: data.get("password"),
        }
        codeReq("POST", "assets/backend/checkUser.php", (result) => {
          let value = JSON.parse(result)

          if (!value.Error) {
            sessionStorage.setItem("ID", value.ID);
            swal("Welcome", "Welcome to the NEO-Core", "success").then((result) => {
              document.cookie = "isLoggedIn=true"
              sessionStorage.setItem("loggedIn", true)
              if (result) {
                window.location.href = "landing_page.php"
              } else {
                window.location.href = "landing_page.php"
              }
            });
          } else {
            swal("Incorrect Credentials", "", "error");
            document.querySelector("#signin").reset();
            grecaptcha.reset(logWidget)
          }
        }, userdata)
      }

    })

    function validateEmail(email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(email);
    }

    function getRandomNumber(min, max) {
      return Math.floor(Math.random() * (max - min + 1) + min);
    }


    document.querySelector("#register").addEventListener("click", (e) => {
      e.preventDefault()
      document.querySelector("#register").style.display = "none"
      let response = grecaptcha.getResponse(regWidget);
      if (response == '') {
        swal("You forgot something", "Please fill the captcha", "error");
        document.querySelector("#register").style.display = "block"
      } else {
        const email = document.querySelector("#email")
        const singupform = document.getElementById("singup")
        const data = new FormData(singupform);
        if (data.get("fname").length === 0 || data.get("mname").length === 0 || data.get("lname") === 0 || data.get("email") === 0 || data.get("pass") === 0 || data.get("copass").length === 0 || data.get("birthday").length === 0 || data.get("gender").length === 0) {
          swal("Not Satisfied", "Please fill all fields", "error");
          document.querySelector("#register").style.display = "block"
        } else {
          if (validateEmail(email.value)) {
            if (data.get("pass") != data.get("copass")) {
              swal("Not Satisfied", "Passwords do not match", "error");
              document.querySelector("#register").style.display = "block"
            } else {
              var otp = getRandomNumber(10001, 99999)
              sessionStorage.setItem("OTP", otp)
              sessionStorage.setItem("fname", data.get("fname"))
              sessionStorage.setItem("mname", data.get("mname"))
              sessionStorage.setItem("lname", data.get("lname"))
              sessionStorage.setItem("email", data.get("email"))
              sessionStorage.setItem("birthday", data.get("birthday"))
              sessionStorage.setItem("gender", data.get("gender"))
              sessionStorage.setItem("pass", data.get("pass"))
              let userdata = {
                email: data.get("email"),
                otp: otp
              }
              codeReq("POST", "assets/backend/otp/mail.php", (result) => {
                let value = JSON.parse(result)
                if (value[0].Error) {
                  swal("Im sorry!", "Something went wrong", "warning");
                  document.querySelector("#register").style.display = "block"
                } else {
                  swal("There's a code sent to your email", "Check it out!", "success", {
                    backdrop: "static",
                    allowOutsideClick: false
                  }).then((okay) => {
                    if (okay) {
                      window.location.href = "otps.php"
                    } else {
                      window.location.href = "otps.php"
                    }
                  });
                }
              }, userdata)


            }
          } else {
            swal("Not Satisfied", "Please fill a valid email", "error");
            document.querySelector("#register").style.display = "block"
          }
        }



      }

    })
  </script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>

</html>