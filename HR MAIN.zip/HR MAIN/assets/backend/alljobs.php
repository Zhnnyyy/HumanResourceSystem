<?php

include "connection.php";

$sql = $con->prepare("select * from jobs");
$sql->bind_result($id, $title, $desc, $salary, $loc);
$arr = array();
$data = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        $arr['ID'] = $id;
        $arr['TITLE'] = $title;
        $arr['DESC'] = $desc;
        $arr['SALARY'] = $salary;
        $arr['LOCATION'] = $loc;
        array_push($data, $arr);
    }

    echo json_encode($data);
}
