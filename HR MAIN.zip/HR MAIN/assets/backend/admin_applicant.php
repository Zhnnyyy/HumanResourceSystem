<?php
include "connection.php";
$img = base64_encode(file_get_contents($_FILES['img']['tmp_name']));
$imgType = $_FILES['img']['type'];
$cv = base64_encode(file_get_contents($_FILES['resume']['tmp_name']));
$cvType = $_FILES['resume']['type'];
$requirements = $_FILES['requirement']['tmp_name'];
$requirementsType = $_FILES['requirement']['type'];
$date = $_POST['date'];
$ID = $_POST['UID'];
$title = null;
$const = $con->prepare("SET GLOBAL max_allowed_packet = 16777216");
$const->execute();
$sql = $con->prepare("INSERT INTO `applicant`(`AccountID`,`Resume`, `cvtype`, `Image`, `imgtype`, `Date`,`Position`,`status`) VALUES ('$ID','$cv','$cvType','$img','$imgType','$date','$title', 'completed')");
$arr = array();
if ($sql->execute()) {
    for ($i = 0; $i < count($requirements); $i++) {
        $docu = base64_encode(file_get_contents($requirements[$i]));
        $type = $requirementsType[$i];
        insertReq(getCurrentApplicant(), $docu, $type, $date);
    }
    $arr["Error"] = false;
} else {
    $arr["Error"] = true;
}
echo json_encode($arr);

function insertReq($id, $docu, $type, $date)
{
    include "connection.php";
    $sql1 = $con->prepare("INSERT INTO `requirements`(`ApplicantID`,`Attachment`, `attachmentType`, `Date`) VALUES ('$id','$docu','$type','$date')");
    $sql1->execute();
}
function getCurrentApplicant()
{
    include "connection.php";
    $sql = $con->prepare("SELECT applicant.ID FROM applicant ORDER BY applicant.ID DESC limit 1");
    $sql->bind_result($id);
    $sql->execute();
    $sql->fetch();
    return $id;
}
