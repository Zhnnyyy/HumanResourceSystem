<?php
include "connection.php";
// $SERVER_DATA = stripslashes(file_get_contents("php://input"));
// $_POST = json_decode($SERVER_DATA, true);
$fname = (string) $_POST["fname"];
$mname = (string) $_POST['mname'];
$lname = (string) $_POST['lname'];
$bday = (string) $_POST['birthday'];
$gender = (string) $_POST['gender'];
$email = (string) $_POST['email'];
$password = (string) md5($_POST['pass']);
$sql = $con->prepare("INSERT INTO `webaccount`(`Firstname`, `Middlename`, `Lastname`, `Birthday`, `Gender`, `email`, `password`) VALUES ('$fname','$mname','$lname','$bday','$gender','$email','$password')");
// $sql->bind_param("ssssss", null, $fname, $mname, $lname, $email, $password);
$data = array();
$raw_data = array();
if ($sql->execute()) {
    $raw_data['Message'] = "Account has been created";
    $raw_data['Error'] = false;
    array_push($data, $raw_data);
    $con->close();
} else {
    $raw_data['Message'] = "Failed to create account";
    $raw_data['Error'] = true;
    array_push($data, $raw_data);
}
echo json_encode($data);
