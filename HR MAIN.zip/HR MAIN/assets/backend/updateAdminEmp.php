<?php
include "connection.php";
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$bday = $_POST['bday'];
$gender = $_POST['gender'];
$shift = $_POST['shift'];
$type = $_POST['type'];
$pos = $_POST['pos'];
$dept = $_POST['dept'];
$id = $_POST['id'];
$sql = $con->prepare("UPDATE `employee` SET `Firstname`='$fname',`Middlename`='$mname',`Lastname`='$lname',`Gender`='$gender',`Birthday`='$bday',`Email`='$email',`Position`='$pos',`PositionType`='$type',`Shift`='$shift',`Department`='$dept' WHERE EmployeeID = '$id'");
if ($sql->execute()) {
    echo json_encode(array("Error" => false));
} else {
    echo json_encode(array("Error" => true));
}
