<?php

include "connection.php";

$sql = $con->prepare("SELECT employee.EmployeeID, employee.Firstname, employee.Middlename, employee.Lastname, employee.Gender, employee.Birthday, jobposition.PositionName, employeetype.EmployeeType, employee.Email, employee.ApplicantID, workshift.ShiftName, department.DepartmentName, employee.DateHired from employee INNER JOIN jobposition on jobposition.ID = employee.Position INNER JOIN employeetype on employeetype.ID = employee.PositionType INNER JOIN workshift on workshift.ID = employee.Shift INNER JOIN department on department.ID = employee.Department");
$sql->bind_result($id, $fname, $mname, $lname, $gender, $bday, $pos, $postype, $email, $keyID, $shift, $dept, $datehired);
$arr = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($arr, array("EMPID" => $id, "FNAME" => $fname, "MNAME" => $mname, "LNAME" => $lname, "GENDER" => $gender, "BDAY" => $bday, "POS" => $pos, "POSTYPE" => $postype, "EMAIL" => $email, "KEYID" => $keyID, "SHIFT" => $shift, "DEPT" => $dept, "DATE" => $datehired));
    }
    echo json_encode($arr);
}
