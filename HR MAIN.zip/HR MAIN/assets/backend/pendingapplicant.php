<?php

include "connection.php";

$sql = $con->prepare("SELECT webaccount.Firstname, webaccount.Middlename, webaccount.Lastname, applicant.Resume, applicant.cvtype, applicant.Position, applicant.Image, applicant.imgtype,  applicant.Date, applicant.ID FROM applicant INNER JOIN webaccount on  applicant.AccountID = webaccount.ID  WHERE applicant.status = 'pending'");
$sql->bind_result($fname, $mname, $lname, $cv, $cvtype, $position, $img, $imgtype, $date, $id);
$arr = array();
$data = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        $arr['fname'] = $fname;
        $arr['mname'] = $mname;
        $arr['lname'] = $lname;
        $arr['position'] = $position;
        $arr['cv'] = $cv;
        $arr['cvtype'] = $cvtype;
        $arr['img'] = $img;
        $arr['imgtype'] = $imgtype;
        $arr['date'] = $date;
        $arr['id'] = $id;
        array_push($data, $arr);
    }

    echo json_encode($data);
}
