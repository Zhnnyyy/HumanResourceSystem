<?php
session_start();
include "connection.php";
$SERVERDATA = stripslashes(file_get_contents("php://input"));
$DATA = json_decode($SERVERDATA, true);
$email = $DATA['email'];
$pass = md5($DATA['pass']);
// $email = $_POST['email'];
// $pass = md5($_POST['pass']);
$sql = $con->prepare("select ID, count(*) from webaccount where email ='$email' and password= '$pass'");
$sql->bind_result($id, $result);
$arr = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        if ($result == 0) {
            $arr["Error"] = true;
        } else {
            $arr["Error"] = false;
            $arr["ID"] = $id;
            $_SESSION["USER"] = true;
        }
    }
    echo json_encode($arr);
}
