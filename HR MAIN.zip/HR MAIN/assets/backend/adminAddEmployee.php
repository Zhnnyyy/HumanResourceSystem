<?php


include "connection.php";
$position = getPosID();
$employeeID = $_POST['employeeID'];
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$date = $_POST['date'];
$pin = md5("neocore");
$email = $_POST['email'];
$gender = $_POST['gender'];
$birthday = $_POST['birthday'];
$department = getDeptID();
$employmenttype = getPosType();
$manager = $_POST['adminmanager'];
$shift = getShiftID();
$query = "";
$posID = getpositionID();
$applicantID = getCurrentApplicant();
if (empty($manager) || $manager === "null") {
    $query = "INSERT INTO `employee`(`ApplicantID`, `EmployeeID`, `Pin`, `Firstname`, `Middlename`, `Lastname`, `Gender`, `Birthday`, `Email`, `Position`, `PositionType`, `Shift`, `Department`, `DateHired`, `status`) VALUES ('$applicantID','$employeeID','$pin','$fname','$mname','$lname','$gender','$birthday','$email','$posID','$employmenttype','$shift','$department','$date', 'boarding')";
} else {
    $query = "INSERT INTO `employee`(`ApplicantID`, `EmployeeID`, `Pin`, `Firstname`, `Middlename`, `Lastname`, `Gender`, `Birthday`, `Email`, `Position`, `PositionType`, `Shift`, `Department`, `Manager`, `DateHired`,`status`) VALUES ('$applicantID','$employeeID','$pin','$fname','$mname','$lname','$gender','$birthday','$email','$posID','$employmenttype','$shift','$department','$manager','$date', 'boarding')";
}
$sql = $con->prepare($query);

function getPosID()
{
    include "connection.php";
    $position = $_POST['position'];
    $sql = $con->prepare("select ID from jobposition where PositionName ='$position'");
    $sql->bind_result($id);
    $sql->execute();
    $sql->fetch();
    return $id;
}

function getPosType()
{
    include "connection.php";
    $employmenttype = $_POST['employeetype'];
    $sql = $con->prepare("select ID from employeetype where EmployeeType ='$employmenttype'");
    $sql->bind_result($id);
    $sql->execute();
    $sql->fetch();
    return $id;
}

function getShiftID()
{
    include "connection.php";
    $shift = $_POST['shift'];
    $sql = $con->prepare("select ID from workshift where ShiftName ='$shift'");
    $sql->bind_result($id);
    $sql->execute();
    $sql->fetch();
    return $id;
}

function getDeptID()
{
    include "connection.php";
    $department = $_POST['department'];
    $sql = $con->prepare("select ID from department where DepartmentName ='$department'");
    $sql->bind_result($id);
    $sql->execute();
    $sql->fetch();
    return $id;
}
function getCurrentApplicant()
{
    include "connection.php";
    $sql = $con->prepare("SELECT applicant.ID FROM applicant ORDER BY applicant.ID DESC limit 1");
    $sql->bind_result($id);
    $sql->execute();
    $sql->fetch();
    return $id;
}

function getpositionID()
{
    include "connection.php";
    $pos = $_POST['position'];
    $sql = $con->prepare("SELECT `ID` FROM `jobposition` WHERE PositionName = '$pos'");
    $sql->bind_result($uid);
    $sql->execute();
    $sql->fetch();
    return $uid;
}

function updateApplicant($id)
{
    include "connection.php";
    $sql = $con->prepare("UPDATE `applicant` SET `status`='completed' WHERE ID= '$id'");
    if ($sql->execute()) {
        echo json_encode(array("Error" => false));
    } else {
        echo json_encode(array("Error" => true));
    }
}

function addCredits($id)
{
    include "connection.php";
    $sql = $con->prepare("INSERT INTO `employeecredits`(`EmployeeID`, `Vacation leave`, `Sick leave`, `Parental leave`, `Maternity leave`, `Paternity leave`, `Personal leave`) VALUES ('$id','3','3','3','3','3','3')");
    $sql->execute();
}
if ($sql->execute()) {
    updateApplicant($applicantID);
    addCredits($employeeID);
} else {
    echo json_encode(array("Error" => true));
}
