<?php

include "connection.php";
$date1 = $_POST['startdate'];
$date2 = $_POST['enddate'];
$sql = $con->prepare("select attendance.EmployeeID, concat(employee.Firstname, ' ', employee.Lastname) as Name, attendance.TimeIn, attendance.TimeOut, attendance.WorkHours, attendance.Date from attendance INNER JOIN employee on employee.EmployeeID = attendance.EmployeeID WHERE attendance.Date >='$date1' and attendance.Date <= '$date2' ORDER BY attendance.Date DESC");
$sql->bind_result($id, $name, $timein, $timeout, $wrkhrs, $date);
$arr = array();

if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($arr, array("ID" => $id, "NAME" => $name, "TIMEIN" => $timein, "TIMEOUT" => $timeout, "WORKHRS" => $wrkhrs, "DATE" => $date));
    }
    echo json_encode($arr);
}
