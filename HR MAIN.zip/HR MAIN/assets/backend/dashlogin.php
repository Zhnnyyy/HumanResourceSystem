<?php
session_start();
include "connection.php";
$user = $_POST['username'];
$pass = md5($_POST['password']);

$sql = $con->prepare("SELECT COUNT(*)as total, department.DepartmentName, concat(employee.Firstname, ' ', employee.Lastname)as Name from employee INNER JOIN department on department.ID = employee.Department WHERE employee.EmployeeID = '$user' and employee.Pin ='$pass';");
$sql->bind_result($total, $position, $name);
if ($sql->execute()) {
    $sql->fetch();
    if ($total > 0) {

        $_SESSION['isLoggedIn'] = true;
        if ($position === "Admin Department") {
            $_SESSION['NAME'] = "ADMIN | " . $name;
            $_SESSION['isAdmin'] = "true";
            echo json_encode(array("Error" => false, "isAdmin" => true, "Name" => $_SESSION['NAME'], "isLoggedIn" => true));
        } else if (($position === "HR Department")) {
            $_SESSION['NAME'] = "HR | " . $name;
            $_SESSION['isAdmin'] = "false";
            echo json_encode(array("Error" => false, "isAdmin" => false, "Name" => $_SESSION['NAME'], "isLoggedIn" => true));
        } else {
            echo json_encode(array("Error" => true, "isAdmin" => false));
        }
    } else {
        echo json_encode(array("Error" => true));
    }
}
