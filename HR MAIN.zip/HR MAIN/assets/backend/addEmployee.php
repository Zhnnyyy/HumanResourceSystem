<?php


include "connection.php";
$applicantID = $_POST['applicantID'];
$position = $_POST['position'];
$employeeID = $_POST['employeeID'];
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$date = $_POST['date'];
$pin = md5("neocore");
$email = $_POST['email'];
$gender = $_POST['gender'];
$birthday = $_POST['birthday'];
$department = $_POST['department'];
$employmenttype = $_POST['employeetype'];
$manager = $_POST['manager'];
$shift = $_POST['shift'];
$query = "";
$posID = getpositionID();
if (empty($manager) || $manager === "null") {
    $query = "INSERT INTO `employee`(`ApplicantID`, `EmployeeID`, `Pin`, `Firstname`, `Middlename`, `Lastname`, `Gender`, `Birthday`, `Email`, `Position`, `PositionType`, `Shift`, `Department`, `DateHired`, `status`) VALUES ('$applicantID','$employeeID','$pin','$fname','$mname','$lname','$gender','$birthday','$email','$posID','$employmenttype','$shift','$department','$date', 'boarding')";
} else {
    $query = "INSERT INTO `employee`(`ApplicantID`, `EmployeeID`, `Pin`, `Firstname`, `Middlename`, `Lastname`, `Gender`, `Birthday`, `Email`, `Position`, `PositionType`, `Shift`, `Department`, `Manager`, `DateHired`,`status`) VALUES ('$applicantID','$employeeID','$pin','$fname','$mname','$lname','$gender','$birthday','$email','$posID','$employmenttype','$shift','$department','$manager','$date', 'boarding')";
}
$sql = $con->prepare($query);

function getpositionID()
{
    include "connection.php";
    $pos = $_POST['position'];
    $sql = $con->prepare("SELECT `ID` FROM `jobposition` WHERE PositionName = '$pos'");
    $sql->bind_result($uid);
    $sql->execute();
    $sql->fetch();
    return $uid;
}

function updateApplicant($id)
{
    include "connection.php";
    $sql = $con->prepare("UPDATE `applicant` SET `status`='completed' WHERE ID= '$id'");
    if ($sql->execute()) {
        echo json_encode(array("Error" => false));
    } else {
        echo json_encode(array("Error" => true));
    }
}

function addCredits($id)
{
    include "connection.php";
    $sql = $con->prepare("INSERT INTO `employeecredits`(`EmployeeID`, `Vacation leave`, `Sick leave`, `Parental leave`, `Maternity leave`, `Paternity leave`, `Personal leave`) VALUES ('$id','3','3','3','3','3','3')");
    $sql->execute();
}
if ($sql->execute()) {
    updateApplicant($applicantID);
    addCredits($employeeID);
} else {
    echo json_encode(array("Error" => true));
}
