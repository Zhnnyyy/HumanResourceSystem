<?php

include "connection.php";

$ID = $_POST['ID'];

$sql = $con->prepare("SELECT  `Resume`, `cvtype` FROM `applicant` WHERE ID='$ID'");
$sql->bind_result($data, $mime);
$arr = array();
$raw = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        $arr['type'] = $mime;
        $arr['content'] = $data;
        array_push($raw, $arr);
    }
    echo json_encode($raw);
}
