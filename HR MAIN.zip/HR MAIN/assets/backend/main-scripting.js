export function codeReq(method, path, response, data = {}) {
  const server = new XMLHttpRequest();
  server.open(method, path, true);
  server.setRequestHeader("Content-Type", "application/json");
  // server.setRequestHeader("Accept", "application/json");
  server.onload = () => {
    if (server.status === 200) {
      response(server.responseText);
    } else {
      server.abort();
    }
  };
  server.send(JSON.stringify(data));
}

export function userReq(method, path, response, data) {
  const server = new XMLHttpRequest();
  server.open(method, path, true);
  server.onload = () => {
    if (server.status === 200) {
      response(server.responseText);
    } else {
      server.abort();
    }
  };
  server.send(data);
}

// const server = new XMLHttpRequest();
// server.open("POST", "assets/backend/applicant.php", true);
// server.onload = () => {
//   if (server.status === 200) {
//     console.log(server.responseText);
//   } else {
//     console.log("Bad Connection");
//   }
// };
// server.send(formdata);
