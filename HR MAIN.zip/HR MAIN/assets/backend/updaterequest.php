<?php

include "connection.php";
$id = $_POST['id'];
$status = $_POST['status'];
$sql = $con->prepare("UPDATE `requestlog` SET `Status`='$status' WHERE ID ='$id'");
if ($sql->execute()) {
    echo json_encode(array("Error" => false));
} else {
    echo json_encode(array("Error" => true));
}
