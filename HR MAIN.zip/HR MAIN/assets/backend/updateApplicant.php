<?php

include "connection.php";
$ID = $_POST['id'];
$STATUS = $_POST['status'];

$sql = $con->prepare("UPDATE `applicant` SET `status`='$STATUS' WHERE ID='$ID'");
if ($sql->execute()) {
    echo json_encode(array("Error" => false));
} else {
    echo json_encode(array("Error" => true));
}
