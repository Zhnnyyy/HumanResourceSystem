<?php

include "connection.php";
$position = $_POST['position'];
$dept = $_POST['department'];
$shift = $_POST['shift'];
$type = $_POST['employeetype'];
$id = $_POST['id'];
$sql = $con->prepare("UPDATE `employee` SET `Position`='$position',`PositionType`='$type',`Shift`='$shift',`Department`='$dept' WHERE EmployeeID ='$id'");
if ($sql->execute()) {
    echo json_encode(array("Error" => false));
} else {
    echo json_encode(array("Error" => true));
}
