<?php
include "connection.php";
$ID = $_POST['ID'];
$sql1 = $con->prepare("SELECT requirements.ID, requirements.Attachment, requirements.attachmentType FROM applicant INNER JOIN requirements on applicant.ID = requirements.ApplicantID WHERE applicant.status = 'pending' and applicant.ID = '$ID'");
$sql1->bind_result($id, $attachment, $attachmenttype);
$raw = array();
$raw_data = array();
if ($sql1->execute()) {
    while ($sql1->fetch()) {
        $raw['ID'] = $id;
        $raw['attachment'] = $attachment;
        $raw['attachmenttype'] = $attachmenttype;
        array_push($raw_data, $raw);
    }
    echo json_encode($raw_data);
}
