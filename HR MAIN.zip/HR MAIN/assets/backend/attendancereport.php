<?php

include "connection.php";
$id = $_POST['ID'];
$date1 = $_POST['startdate'];
$date2 = $_POST['enddate'];
$sql = $con->prepare("SELECT `Date`, `status` FROM `attendance` WHERE EmployeeID ='$id' and Date >='$date1' and Date <= '$date2' ORDER by Date ASC");
$sql->bind_result($date, $status);
$arr = array();

if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($arr, array("date" => $date, "status" => $status));
    }
    echo json_encode($arr);
}
