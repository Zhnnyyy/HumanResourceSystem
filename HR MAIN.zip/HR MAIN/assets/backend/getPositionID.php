<?php

include "connection.php";
$id = $_POST['id'];
$sql = $con->prepare("SELECT `ID` FROM `jobposition` WHERE PositionName = '$id'");
$sql->bind_result($uid);
$arr = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        $arr['id'] = $uid;
    }
    echo json_encode($arr);
}
