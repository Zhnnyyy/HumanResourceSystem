<?php

include "connection.php";

$sql = $con->prepare("select employee.EmployeeID, employee.Firstname, employee.Middlename, employee.Lastname, employee.Gender, employee.Birthday, employee.Email, jobposition.PositionName, jobposition.Rate as Rate, employeetype.EmployeeType, workshift.ShiftName, department.DepartmentName, employee.Manager, employee.DateHired from employee INNER JOIN jobposition on jobposition.ID = employee.Position INNER JOIN employeetype on employeetype.ID = employee.PositionType INNER JOIN workshift on workshift.ID = employee.Shift INNER JOIN department on department.ID = employee.Department");
$sql->bind_result($empID, $fname, $mname, $lname, $gender, $bday, $email, $posName, $posRate, $empType, $shift, $dept, $manager, $datehired);
$arr = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($arr, array("ID" => $empID, "fname" => $fname, "mname" => $mname, "lname" => $lname, "gender" => $gender, "bday" => $bday, "email" => $email, "posName" => $posName, "posRate" => $posRate, "empType" => $empType, "shift" => $shift, "dept" => $dept, "manager" => $manager, "datehired" => $datehired, "managerName" => getManagerName($manager)));
    }
    echo json_encode($arr);
}
function getManagerName($id)
{
    include "connection.php";
    if (empty($id)) {
        return "";
    } else {
        $sql = $con->prepare("select concat(Firstname, ' ', Lastname) as Name from employee where EmployeeID = '$id'");
        $sql->bind_result($name);
        $sql->execute();
        $sql->fetch();
        return $name;
    }
}
