<?php

include "connection.php";

$sql = $con->prepare("SELECT requestlog.ID, requestlog.EmployeeID,concat(employee.Firstname, ' ', employee.Lastname)as name, employeerequest.LeaveName, requestlog.Message, requestlog.StartDate, requestlog.EndDate, requestlog.Date from requestlog INNER JOIN employee on employee.EmployeeID = requestlog.EmployeeID INNER JOIN employeerequest on employeerequest.ID = requestlog.RequestType WHERE requestlog.Status = 'pending'");
$sql->bind_result($uid, $id, $name, $type, $msg, $start, $end, $date);
$arr = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($arr, array("ID" => $id, "NAME" => $name, "TYPE" => $type, "MESSAGE" => $msg, "START" => $start, "END" => $end, "DATE" => $date, "REQID" => $uid));
    }
    echo json_encode($arr);
}
