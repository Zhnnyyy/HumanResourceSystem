<?php

include "connection.php";
$sql = $con->prepare("select webaccount.ID, applicant.ID as ApplicantID, concat(webaccount.Firstname, ' ',webaccount.Lastname) as Name, webaccount.Firstname, webaccount.Middlename, webaccount.Lastname, webaccount.email, webaccount.Gender, webaccount.Birthday, jobposition.Rate, applicant.Position from applicant INNER JOIN webaccount on webaccount.ID = applicant.AccountID INNER JOIN jobposition on jobposition.PositionName = applicant.Position where applicant.status = 'accepted'");
$sql->bind_result($webAccountID, $applicantID, $name, $firstname, $middlename, $lastname, $email, $gender, $birthday, $salary, $position);
$arr = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($arr, array("webID" => $webAccountID, "applicantID" => $applicantID, "name" => $name, "fname" => $firstname, "mname" => $middlename, "lname" => $lastname, "email" => $email, "gender" => $gender, "birthday" => $birthday, "salary" => $salary, "position" => $position));
    }
} else {
    array_push($arr, array("Error" => true));
}
echo json_encode($arr);
