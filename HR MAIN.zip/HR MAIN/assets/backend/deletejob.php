<?php

include "connection.php";
$id = $_POST['id'];
$sql = $con->prepare("DELETE FROM `jobs` WHERE ID= '$id'");
if ($sql->execute()) {
    echo json_encode(array("Error" => false));
} else {
    echo json_encode(array("Error" => true));
}
