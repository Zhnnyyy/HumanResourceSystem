<?php

include "connection.php";
$title = $_POST['position'];
$desc = $_POST['desc'];
$salary = $_POST['salary'];
$location = $_POST['location'];
$sql = $con->prepare("insert into jobs values('null', '$title', '$desc', '$salary', '$location')");
$arr = array();
$data = array();
if ($sql->execute()) {
    $arr["Error"] = false;
} else {
    $arr["Error"] = true;
}
echo json_encode($arr);
