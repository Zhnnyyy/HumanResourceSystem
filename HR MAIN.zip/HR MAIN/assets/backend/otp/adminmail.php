<?php
require_once 'Exception.php';
require_once 'PHPMailer.php';
require_once 'SMTP.php';
// $SERVER_DATA = stripslashes(file_get_contents("php://input"));
// $mdata = json_decode($SERVER_DATA, true);
// $email = (string) $mdata["email"];
// $otp = (string) $mdata['otp'];
$email = $_POST["email"];
$msg = $_POST['msg'];
$mail = new PHPMailer\PHPMailer\PHPMailer();
$mail->isHTML(true);
$mail->setFrom("neocore34@gmail.com", "Neo-Core Corporation");
$mail->addAddress($email);
$mail->Subject = "NeoCore Admin";
$mail->Body = $msg;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = "neocore34@gmail.com";
$mail->Password = "pemzisznqycnkqat";
$mail->SMTPSecure = 'tls';
$mail->Port = 587;
$data = array();
$raw_data = array();
if ($mail->send()) {
    $raw_data['Error'] = false;
    array_push($data, $raw_data);
} else {
    // $raw_data['Error'] = $mail->ErrorInfo;
    $raw_data['Error'] = true;
    $raw_data['Data'] = $mail->ErrorInfo;
    array_push($data, $raw_data);
}
echo json_encode($data);
