<?php
require_once 'Exception.php';
require_once 'PHPMailer.php';
require_once 'SMTP.php';
$SERVER_DATA = stripslashes(file_get_contents("php://input"));
$mdata = json_decode($SERVER_DATA, true);
$email = (string) $mdata["email"];
$otp = (string) $mdata['otp'];
// $email = $_POST["user"];
// $otp = $_POST['uotp'];
$mail = new PHPMailer\PHPMailer\PHPMailer();
$mail->isHTML(true);
$mail->setFrom("neocore34@gmail.com", "Neo-Core Corporation");
$mail->addAddress($email);
$mail->Subject = "NeoCore Account";
$mail->Body = '<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Verification</title>
  <style>
  .card {
    background-color: #f0f0f0;
    padding: 20px;
    border-radius: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
    width: 100%;
    max-width: 600px; /* set a maximum width for the card */
    margin: 0 auto; /* center the card horizontally */
  }
  
  .card img {
    width: 80px;
    height: 80px;
    margin-bottom: 20px;
  }
  
  .card h2 {
    font-size: 24px;
    margin-bottom: 10px;
  }
  
  .card p.verification-code {
    font-size: 32px;
    font-weight: bold;
    margin: 0;
    padding: 10px 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
  }
  
  /* media query for screens smaller than 768px */
  @media (max-width: 767px) {
    .card {
      padding: 10px;
    }
    
    .card img {
      width: 60px;
      height: 60px;
      margin-bottom: 10px;
    }
    
    .card h2 {
      font-size: 20px;
      margin-bottom: 5px;
    }
    
    .card p.verification-code {
      font-size: 24px;
      padding: 5px 10px;
    }
  }  
  </style>
</head>
<body>
  <div class="card">
    <img
      src="https://z-p3-scontent.fmnl9-1.fna.fbcdn.net/v/t1.15752-9/341903898_1299055620992171_7211393799271550156_n.png?_nc_cat=110&ccb=1-7&_nc_sid=ae9488&_nc_eui2=AeE2SmIon5FjZUUF1Di9HI_U2R9tYto8-83ZH21i2jz7zVQd6LfJ7ktOyo9RUBMvIF_Ic5S-uZaDZSqW6rkOgorI&_nc_ohc=LeOnzt-zJBwAX-faIzZ&_nc_ht=z-p3-scontent.fmnl9-1.fna&oh=03_AdSSapOnc5oSn8JXSsqL1o6F3glraACr0tqizZRlI15dYw&oe=6472023B"
      alt="Company Logo"
    />
    <br>
    <h2>Your verification code</h2>
    <br>
    <p class="verification-code">' . $otp . '</p>
  </div>

</body>
</html>';
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = "neocore34@gmail.com";
$mail->Password = "pemzisznqycnkqat";
$mail->SMTPSecure = 'tls';
$mail->Port = 587;
$data = array();
$raw_data = array();
if ($mail->send()) {
    $raw_data['Error'] = false;
    array_push($data, $raw_data);
} else {
    $raw_data['Error'] = $mail->ErrorInfo;
    $raw_data['Data'] = $email;
    array_push($data, $raw_data);
}
echo json_encode($data);
