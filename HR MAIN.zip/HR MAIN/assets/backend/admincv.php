<?php

include "connection.php";
$id = $_POST['id'];
$sql = $con->prepare("SELECT applicant.Resume, applicant.cvtype from applicant WHERE applicant.ID = '$id'");
$sql->bind_result($data, $type);
if ($sql->execute()) {
    $sql->fetch();
    echo json_encode(array("Error" => false, "data" => $data, "type" => $type));
} else {
    echo json_encode(array("Error" => false));
}
