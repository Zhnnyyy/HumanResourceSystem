<?php

include "../../connection.php";
$id = $_POST['id'];
$sql = $con->prepare("SELECT workshift.ShiftName from employee INNER JOIN workshift on workshift.ID = employee.Shift WHERE employee.EmployeeID = '$id'");
$sql->bind_result($shift);
if ($sql->execute()) {
    $sql->fetch();
    echo json_encode(array("Error" => false, "Shift" => $shift));
} else {
    echo json_encode(array("Error" => true));
}
