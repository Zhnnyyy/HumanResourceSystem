<?php

include "../../connection.php";
$empID = $_POST['UID'];
$date = $_POST['Date'];
$target = $_POST['target'];
$sql = $con->prepare("select count(*) as total, `$target` from attendance where EmployeeID ='$empID' and Date='$date'");
$sql->bind_result($total, $data);
if ($sql->execute()) {
    $sql->fetch();
    if ($target == "TimeIn") {
        if (timeChecker($empID, $date)) {
            echo json_encode(array("Error" => false, "haveValue" => true));
        } else {
            echo json_encode(array("Error" => false, "haveValue" => false));
        }
    }

    if ($target == "TimeOut") {
        if (timeChecker($empID, $date)) {
            if (timeOutChecker($empID, $date)) {
                echo json_encode(array("Error" => false, "haveValue" => false, "msg" => ""));
            } else {
                echo json_encode(array("Error" => false, "haveValue" => true, "msg" => ""));
            }
        } else {
            echo json_encode(array("Error" => false, "haveValue" => false, "msg" => "Nodata"));
        }
    }
} else {
    echo json_encode(array("Error" => true, "haveValue" => null));
}

function timeOutChecker($empID, $date)
{
    include "../../connection.php";
    $sql = $con->prepare("select TimeOut from attendance where EmployeeID ='$empID' and Date='$date'");
    $sql->bind_result($data);
    $sql->execute();
    $sql->fetch();
    if ($data == null) {
        //walang laman
        return true;
    }
    return false;
}

function timeChecker($empID, $date)
{
    include "../../connection.php";
    $sql = $con->prepare("select count(*) from attendance where EmployeeID ='$empID' and Date='$date'");
    $sql->bind_result($count);
    $sql->execute();
    $sql->fetch();
    if ($count > 0) {
        //may laman
        return true;
    }
    return false;
}
