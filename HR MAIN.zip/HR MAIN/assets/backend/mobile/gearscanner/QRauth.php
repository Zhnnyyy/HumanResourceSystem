<?php

include "../../connection.php";
$data = $_POST['qrdata'];
$sql = $con->prepare("select count(*) from employee where EmployeeID = '$data'");
$sql->bind_result($count);
if ($sql->execute()) {
    $sql->fetch();
    echo json_encode(array("Error" => false, "Count" => $count));
} else {
    echo json_encode(array("Error" => true, "Count" => $count));
}
