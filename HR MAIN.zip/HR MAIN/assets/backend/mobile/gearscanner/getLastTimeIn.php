<?php

include "../../connection.php";
$empID = $_POST['UID'];
$date = $_POST['Date'];
$sql = $con->prepare("select TimeIn from attendance where EmployeeID = '$empID' and Date ='$date'");
$sql->bind_result($time);
if ($sql->execute()) {
    $sql->fetch();
    echo json_encode(array("Error" => false, "Time" => $time));
} else {
    echo json_encode(array("Error" => true, "Time" => $time));
}
