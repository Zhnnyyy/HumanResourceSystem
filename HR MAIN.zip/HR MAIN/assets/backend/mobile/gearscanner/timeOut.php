<?php

include "../../connection.php";
$id = $_POST['id'];
$date = $_POST['date'];
$work = $_POST['work'];
$time = $_POST['time'];
$sql = $con->prepare("UPDATE `attendance` SET `TimeOut`='$time',`WorkHours`='$work' WHERE EmployeeID = '$id' and Date ='$date' ");
if ($sql->execute()) {
    echo json_encode(array("Error" => false));
} else {
    echo json_encode(array("Error" => true));
}
