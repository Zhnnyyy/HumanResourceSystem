<?php

include "../../connection.php";
$time = $_POST['time'];
$date = $_POST['date'];
$id = $_POST['id'];
$status = $_POST['status'];
$sql = $con->prepare("INSERT INTO `attendance`(`EmployeeID`, `TimeIn`, `Date`, `status`) VALUES ('$id','$time','$date', '$status')");
if ($sql->execute()) {
    echo json_encode(array("Error" => false));
} else {
    echo json_encode(array("Error" => true));
}
