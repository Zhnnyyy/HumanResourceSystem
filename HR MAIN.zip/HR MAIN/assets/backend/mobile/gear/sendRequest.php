<?php

include "../../connection.php";
$id = $_POST['id'];
$leaveName = getReqID($_POST['leave']);
$msg = $_POST['msg'];
$startDate = $_POST['startdate'];
$endDate = $_POST['enddate'];
$date = $_POST['date'];
$status = "pending";
$sql = $con->prepare("INSERT INTO `requestlog`(`EmployeeID`, `RequestType`, `Message`,`StartDate`,`EndDate`, `Date`, `Status`) VALUES ('$id','$leaveName','$msg','$startDate', '$endDate', '$date','$status')");
if ($sql->execute()) {
    echo json_encode(array("Error" => false));
} else {
    echo json_encode(array("Error" => true));
}
function getReqID($txt)
{
    include "../../connection.php";
    $sql = $con->prepare("SELECT `ID` FROM `employeerequest` WHERE LeaveName = '$txt'");
    $sql->bind_result($ids);
    $sql->execute();
    $sql->fetch();
    return $ids;
}
