<?php

include "../../connection.php";
$user = $_POST['companyid'];
$pass = md5($_POST['password']);
$sql = $con->prepare("SELECT count(*), concat(employee.Firstname, ' ', employee.Middlename, ' ', employee.Lastname) as Name FROM `employee` WHERE EmployeeID ='$user' and Pin = '$pass'");
$sql->bind_result($counting, $name);
if ($sql->execute()) {
    $sql->fetch();
    echo json_encode(array("Error" => false, "Count" => $counting, "name" => $name));
} else {
    echo json_encode(array("Error" => true, "Count" => $counting, "name" => $name));
}
