<?php

include "../../connection.php";
$id = $_POST['id'];
$sql = $con->prepare("SELECT `Vacation leave`, `Sick leave`, `Parental leave`, `Maternity leave`, `Paternity leave`, `Personal leave` FROM `employeecredits` WHERE EmployeeID= '$id'");
$sql->bind_result($vaction, $sick, $parental, $maternity, $paternity, $personal);
$arr = array();
if ($sql->execute()) {
    $sql->fetch();
    array_push($arr, array("Name" => "Vacation", "Credits" => $vaction));
    array_push($arr, array("Name" => "Sick", "Credits" => $sick));
    array_push($arr, array("Name" => "Parental", "Credits" => $parental));
    array_push($arr, array("Name" => "Maternity", "Credits" => $maternity));
    array_push($arr, array("Name" => "Paternity", "Credits" => $paternity));
    array_push($arr, array("Name" => "Personal", "Credits" => $personal));
    echo json_encode($arr);
}
