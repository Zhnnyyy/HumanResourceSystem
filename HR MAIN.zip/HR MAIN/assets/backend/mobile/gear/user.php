<?php

include "../../connection.php";
$ID = $_POST['id'];
$sql = $con->prepare("SELECT concat(employee.Firstname, ' ', employee.Middlename, ' ', employee.Lastname) as Name, employee.Gender, employee.Birthday, employee.Email, jobposition.PositionName, employeetype.EmployeeType, workshift.ShiftName, department.DepartmentName from employee INNER JOIN jobposition ON jobposition.ID = employee.Position INNER JOIN employeetype on employeetype.ID = employee.PositionType INNER JOIN workshift on workshift.ID = employee.Shift INNER JOIN department on department.ID = employee.Department WHERE employee.EmployeeID = '$ID'");
$sql->bind_result($name, $gemder, $bday, $email, $position, $postype, $shift, $dept);
$arr = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($arr, array("name" => $name, "gender" => $gemder, "bday" => $bday, "email" => $email, "position" => $position, "postype" => $postype, "shift" => $shift, "dept" => $dept));
    }
    echo json_encode($arr);
}
