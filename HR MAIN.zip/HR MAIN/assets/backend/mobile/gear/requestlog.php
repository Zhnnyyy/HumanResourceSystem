<?php

include "../../connection.php";
$id = $_POST['id'];
$sql = $con->prepare("SELECT employeerequest.LeaveName,  requestlog.StartDate, requestlog.EndDate,  requestlog.Status FROM `requestlog` INNER JOIN employeerequest on employeerequest.ID = requestlog.RequestType WHERE EmployeeID ='$id' ORDER BY Date DESC");
$sql->bind_result($type, $startdate, $enddate, $status);
$arr = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($arr, array("type" => $type, "startdate" => $startdate, "enddate" => $enddate, "status" => $status));
    }
    echo json_encode($arr);
}
