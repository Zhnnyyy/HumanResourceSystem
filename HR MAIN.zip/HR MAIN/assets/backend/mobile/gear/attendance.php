<?php
include "../../connection.php";
$ID = $_POST['id'];
$sql = $con->prepare("SELECT  `TimeIn`, `TimeOut`, `WorkHours`, `Date` FROM `attendance` WHERE EmployeeID='$ID' order by Date desc");
$sql->bind_result($time1, $time2, $work, $date);
$data = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($data, array("Timein" => $time1, "Timeout" => $time2, "WorkHours" => $work, "Date" => $date));
    }
    echo json_encode($data);
}
