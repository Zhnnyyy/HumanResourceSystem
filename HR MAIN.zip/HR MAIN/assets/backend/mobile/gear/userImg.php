<?php

include "../../connection.php";
$ID = $_POST['id'];
$sql = $con->prepare("select ApplicantID from employee where EmployeeID ='$ID' ");
$sql->bind_result($data);
if ($sql->execute()) {
    $sql->fetch();
    getImage($data);
}

function getImage($value)
{
    include "../../connection.php";
    $sql = $con->prepare("SELECT `Image` FROM `applicant` WHERE ID='$value'");
    $sql->bind_result($img);
    if ($sql->execute()) {
        $sql->fetch();
        echo json_encode(array("Image" => $img));
    }
}
