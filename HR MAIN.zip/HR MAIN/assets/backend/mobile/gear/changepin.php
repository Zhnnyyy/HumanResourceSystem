<?php

include "../../connection.php";
$id = $_POST['id'];
$pin = md5($_POST['pin']);
$sql = $con->prepare("UPDATE employee SET Pin ='$pin' where EmployeeID ='$id'");
if ($sql->execute()) {
    echo json_encode(array("Error" => false));
} else {
    echo json_encode(array("Error" => true));
}
