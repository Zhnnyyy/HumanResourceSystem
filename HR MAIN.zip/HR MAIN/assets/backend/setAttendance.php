<?php

include "connection.php";
$id = $_POST['id'];
$date = $_POST['date'];
$sql = $con->prepare("INSERT INTO `attendance`(`EmployeeID`,`Date`, `status`) VALUES ('$id','$date','leave')");
if ($sql->execute()) {
    echo json_encode(array("Error" => false));
} else {
    echo json_encode(array("Error" => true));
}
