<?php

include "connection.php";
$id = $_POST['id'];
$tbl = $_POST['tbl'];
//get 
$query = "SELECT `$tbl` FROM `employeecredits` WHERE EmployeeID = '$id'";
$sql = $con->prepare($query);
$sql->bind_result($data);
$sql->execute();
$sql->fetch();
$updatedCredits = $data - 1;
updateNow($updatedCredits, $tbl, $id);
function updateNow($updatedCredits, $tbl, $id)
{
    include "connection.php";
    $query = "UPDATE `employeecredits` SET `$tbl`='$updatedCredits' WHERE EmployeeID= '$id'";
    $sql = $con->prepare($query);
    if ($sql->execute()) {
        echo json_encode(array("Error" => false));
    } else {
        echo json_encode(array("Error" => true));
    }
}
