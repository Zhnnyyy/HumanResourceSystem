<?php

include "connection.php";

$sql = $con->prepare("select attendance.EmployeeID, concat(employee.Firstname, ' ', employee.Lastname) as Name, attendance.TimeIn, attendance.TimeOut, attendance.WorkHours, attendance.Date, attendance.status from attendance INNER JOIN employee on employee.EmployeeID = attendance.EmployeeID ORDER BY attendance.Date DESC");
$sql->bind_result($id, $name, $timein, $timeout, $wrkhrs, $date, $status);
$arr = array();

if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($arr, array("ID" => $id, "NAME" => $name, "TIMEIN" => $timein, "TIMEOUT" => $timeout, "WORKHRS" => $wrkhrs, "DATE" => $date, "STATUS" => $status));
    }
    echo json_encode($arr);
}
