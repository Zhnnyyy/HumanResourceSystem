<?php

$con = new mysqli("localhost", "root", "", "neocore");

if (!$con) {
    die($con);
}
