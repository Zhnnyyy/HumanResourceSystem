<?php

include "connection.php";
$id = $_POST['id'];
$title = $_POST['position'];
$desc = $_POST['desc'];
$salary = $_POST['salary'];
$location = $_POST['location'];
$sql = $con->prepare("UPDATE `jobs` SET`JobTitle`='$title',`JobDescription`='$desc',`Salary`='$salary',`Location`='$location' WHERE ID = '$id'");
if ($sql->execute()) {
    echo json_encode(array("Error" => false, "ID" => $id));
} else {
    echo json_encode(array("Error" => true));
}
