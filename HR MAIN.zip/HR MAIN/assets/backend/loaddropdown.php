<?php



function loadDepartment()
{
    return query("SELECT `ID`, `DepartmentName` FROM `department`");
}

function loadWorkShift()
{
    return query("SELECT `ID`,`ShiftName` FROM `workshift`");
}

function loadEmploymentType()
{
    return query("SELECT `ID`, `EmployeeType` FROM `employeetype`");
}
function lodaJobposition()
{
    return query("SELECT `ID`, `PositionName`FROM `jobposition`");
}
function loadManager()
{
    return query("SELECT employee.EmployeeID, concat(employee.Firstname, ' ', employee.Lastname) as Name from employee INNER JOIN jobposition on jobposition.ID = employee.Position WHERE employee.Position = 7 and employee.Manager is null");
}
$data = array();
array_push($data, array("Department" => loadDepartment()));
array_push($data, array("WorkShift" => loadWorkShift()));
array_push($data, array("EmploymentType" => loadEmploymentType()));
array_push($data, array("JobPosition" => lodaJobposition()));
array_push($data, array("Manager" => loadManager()));
echo json_encode($data);
function query($que)
{
    include "connection.php";
    $sql = $con->prepare($que);
    $sql->bind_result($id, $name);
    $arr = array();
    if ($sql->execute()) {
        while ($sql->fetch()) {
            array_push($arr, array("ID" => $id, "Name" => $name));
        }
    }
    return $arr;
}
