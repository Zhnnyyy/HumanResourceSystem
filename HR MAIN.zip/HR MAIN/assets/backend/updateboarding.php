<?php

include "connection.php";
$id = $_POST['id'];

$sql = $con->prepare("UPDATE `employee` SET `status`='completed' WHERE EmployeeID ='$id'");
if ($sql->execute()) {
    echo json_encode(["Error" => false]);
} else {
    echo json_encode(["Error" => true]);
}
