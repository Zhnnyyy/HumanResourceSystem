<?php

include "connection.php";
$sql = $con->prepare("SELECT employee.EmployeeID, concat(employee.Firstname,  ' ', employee.Lastname)as name, department.DepartmentName, jobposition.PositionName, employee.DateHired, employee.Email, employee.ApplicantID FROM employee INNER JOIN department on department.ID = employee.Department INNER JOIN jobposition ON jobposition.ID = employee.Position WHERE employee.status = 'boarding'");
$sql->bind_result($id, $name, $dept, $pos, $date, $email, $applicantID);
$arr = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($arr, ["EMPID" => $id, "NAME" => $name, "DEPT" => $dept, "POS" => $pos, "DATE" => $date, "EMAIL" => $email, "appID" => $applicantID]);
    }
    echo json_encode($arr);
}
