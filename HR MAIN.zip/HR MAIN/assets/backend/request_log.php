<?php

include "connection.php";

$sql = $con->prepare("SELECT requestlog.EmployeeID, concat(employee.Firstname, ' ', employee.Lastname) as Name, employeerequest.LeaveName, requestlog.StartDate, requestlog.EndDate, requestlog.Date, requestlog.Status FROM `requestlog` INNER JOIN employee on employee.EmployeeID = requestlog.EmployeeID INNER JOIN employeerequest on employeerequest.ID = requestlog.RequestType");
$sql->bind_result($id, $name, $type, $start, $end, $date, $status);
$arr = array();
if ($sql->execute()) {
    while ($sql->fetch()) {
        array_push($arr, array("ID" => $id, "NAME" => $name, "TYPE" => $type, "START" => $start, "END" => $end, "DATE" => $date, "STATUS" => $status));
    }
    echo json_encode($arr);
}
