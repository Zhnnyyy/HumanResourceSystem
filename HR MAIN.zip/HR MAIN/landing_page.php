<?php
session_start();
$USER = isset($_SESSION['USER']);
if (isset($_SESSION['USER'])) {
  $data = true;
} else {
  $data = false;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>NEO-CORE</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
  <script src="assets/js/OrgChart.js"></script>
  <style>
    body {
      background: rgba(0, 0, 0, 0.6) url(https://images.pexels.com/photos/136413/pexels-photo-136413.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1);
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
      background-blend-mode: darken;
      height: 100vh;
    }

    #job-content {
      visibility: hidden;
      /* display: none; */
    }

    #org {
      display: none;
    }
  </style>
</head>

<body id="dashboardbody">
  <header>
    <!-- style="background-color: #e3f2fd" -->
    <nav class="navbar navbar-expand-lg" style="background-color: #e3f2fd">
      <div class="container-fluid">
        <img src="images/Company-Logo.png" alt="logo" />
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link active" id="home" data-link="home.html" aria-current="page" href="#"><i class="fas fa-home"></i> Home</a>
            <a class="nav-link" id="mission" data-link="statement.html" href="#"><i class="fas fa-handshake"></i> Mission/Vision</a>
            <a class="nav-link" id="branch" data-link="branches.html" href="#"><i class="fas fa-code-branch"></i> Branch</a>
            <a class="nav-link" id="job" data-link="jobs.html" href="#"><i class="fas fa-briefcase"></i> Job Hiring</a>
            <a class="nav-link" id="chart" data-link="charting.php" href="#"><i class="fas fa-sitemap"></i> OrgChart</a>
            <a class="nav-link" id="about" data-link="aboutus.html" href="#"><i class="fas fa-question-circle"></i> About Us</a>
          </div>
        </div>
        <button type="button" class="btn nav-button nav-buttons btn-outline-primary ms-2">
          <i class="fas fa-sign-in-alt" style="color: #1f8bff;"></i> Sign Up
        </button>
        <button type="button" class="btn nav-button nav-buttons btn-primary ms-2"><i class="fas fa-sign-in-alt" style="color: #ffffff;"></i> Sign In</button>
        <button type="button" class="btn nav-button nav-buttons btn-danger" data-link="1"><i class="fas fa-sign-in-alt" style="color: #ffffff;"></i> Logout</button>
      </div>

    </nav>
  </header>
  <div id="org"></div>
  <div class="container info mt-5" id="content"></div>
  <div class="container mt-5" id="job-content">
    <div class="row" id="job-list">
      <div class="col-md-4 mb-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Job Title</h5>

            <p class="card-text">Job Description</p>
            <ul class="list-group list-group-flush">
              <li class="list-group-item">
                <strong>Location:</strong>
              </li>
              <li class="list-group-item">
                <strong>Salary:</strong>
              </li>
              <li class="list-group-item">
                <strong>Requirements:</strong>
                <p>SSS, PhilHealth, Pagibig, Health Certificate, Police Clearance</p>
              </li>
            </ul>
            <button class="btn btn-primary job-btn card-link apply-btn mt-3" data-id="1" data-bs-toggle="modal" data-bs-target="#exampleModal">
              Apply Now
            </button>
          </div>
        </div>
      </div>

    </div>
  </div>


  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <!-- <h5 class="modal-title" id="exampleModalLabel">Modal Title</h5> -->
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="container align-items-center">
            <div class="d-flex justify-content-center">
              <div class="card">
                <!-- card content here -->
                <div class="card-body">
                  <div class="mb-3">
                    <label for="job-title" class="form-label"><strong>Job Title:</strong></label>
                    <p id="job-title-modal"></p>
                  </div>
                  <div class="mb-3">
                    <label for="salary" class="form-label"><strong>Salary:</strong></label>
                    <p id="salary-modal"></p>
                  </div>
                  <!-- <div class="mb-3">
                    <label for="job-type" class="form-label"><strong>Job Type:</strong></label>
                    <p id="job-type-modal"></p>
                  </div> -->
                  <!-- <hr /> -->
                  <form id="applying">
                    <div class="mb-3">
                      <label for="date" class="form-label"><strong>Date:</strong></label>
                      <input type="date" class="form-control" id="date" name="date" />
                    </div>
                    <div class="mb-3">
                      <label for="img" class="form-label"><strong>1x1 Picture:</strong></label>
                      <input type="file" class="form-control" id="img" name="img" />
                    </div>
                    <div class="mb-3">
                      <label for="resume" class="form-label"><strong>Resume/CV:</strong></label>
                      <input type="file" class="form-control" id="resume" name="resume" />
                    </div>
                    <hr />
                    <div class="mb-3">
                      <label for="requirements" class="form-label"><strong>Requirements:</strong></label>
                      <div id="requirements">
                        <div class="input-group mb-3">
                          <input type="file" class="form-control" name="requirement[]" accept=".pdf,.doc,.docx" />
                          <button class="btn btn-outline-danger removeAtt" id="removeAtt" type="button">
                            <i class="fas fa-minus"></i>
                          </button>
                        </div>
                      </div>
                      <button class="btn btn-outline-success" type="button" id="addAtt">
                        <i class="fas fa-plus"></i>
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            Close
          </button>
          <button type="button" id="sendForm" class="btn btn-primary">
            Save changes
          </button>
        </div>
      </div>
    </div>
  </div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="assets/backend/main-scripting.js" type="module"></script>
  <script type="module">
    import {
      codeReq
    } from "./assets/backend/main-scripting.js";
    import {
      userReq
    } from "./assets/backend/main-scripting.js";

    window.onload = function() {
      var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      if (isMobile) {
        swal("Sorry!", "The developer of this site is not allowing you to open this in mobile", "warning").then((result) => {
          if (result) {
            document.querySelector("#dashboardbody").style.display = "none"
          }
          document.querySelector("#dashboardbody").style.display = "none"
        })
      }
    };

    var user = sessionStorage.getItem("loggedIn")
    const container = document.querySelector("#content");
    const main = document.querySelector("body");
    const tag = document.querySelectorAll("a")
    const navBtns = document.querySelectorAll(".nav-buttons")
    const navBtn = document.querySelectorAll(".nav-button")
    let LoggedIn = <?= $USER; ?> + 1;

    if (user) {
      navBtn[0].style.visibility = "hidden";
      navBtn[1].style.visibility = "hidden";
      navBtn[2].style.visibility = "visible"
    } else {
      navBtn[0].style.visibility = "visible";
      navBtn[1].style.visibility = "visible";
      navBtn[2].style.display = "none"
    }

    for (let i = 0; i < navBtns.length; i++) {
      navBtns[i].addEventListener("click", (e) => {
        e.preventDefault()
        let data = navBtns[i].getAttribute("data-link");
        if (data == 1) {

          sessionStorage.clear()
          window.location.href = "landing_page.php"
          return
        }
        window.location.href = "form.php"
      })
    }

    for (let i = 0; i < tag.length; i++) {
      tag[i].addEventListener("click", () => {
        for (let j = 0; j < tag.length; j++) {
          if (tag[j] !== this) {
            tag[j].classList.remove("active")
          }
        }
        tag[i].classList.toggle("active")

        let data = tag[i].getAttribute("data-link")
        main.style.backgroundColor = "rgba(0, 0, 0, 0.6)";
        container.style.display = "block";

        if (i == 4) {
          container.style.display = "none"
          document.querySelector("#job-content").style.visibility = "hidden"
          document.querySelector("#org").style.display = "block"
          return
        }

        if (i == 3) {
          container.style.display = "none"
          document.querySelector("#org").style.display = "none"
          document.querySelector("#job-content").style.visibility = "visible"
          const btns = document.querySelectorAll(".job-btn")
          for (let i = 0; i < btns.length; i++) {
            btns[i].addEventListener("click", () => {
              if (user) {
                let data = btns[i].getAttribute("data-id")

              } else {
                window.location.href = "form.php"
              }


            })
          }
          return
        }
        container.style.display = "block"

        document.querySelector("#org").style.display = "none"
        document.querySelector("#job-content").style.visibility = "hidden"
        codeReq("GET", data, (result) => {
          container.innerHTML = result;
        });
      })
    }

    let nodes = [{
        id: 1,
        name: "Ace Dela Cruz",
        title: "CEO",
        image: "https://z-p3-scontent.fmnl4-4.fna.fbcdn.net/v/t1.15752-9/310539574_838517990783475_4487499420349452023_n.jpg?_nc_cat=102&ccb=1-7&_nc_sid=ae9488&_nc_eui2=AeGCGBLyY2fQMDIva8w_64weIx04rgWfD5AjHTiuBZ8PkBusWqbhV3_z3wxmk2SpRdR2zNomNX_gYq8TBqnHCLUT&_nc_ohc=1K_w3WAbEIcAX8c7Y9l&_nc_ht=z-p3-scontent.fmnl4-4.fna&oh=03_AdRb7qJp55crUdaPszoAkibeFSeaYNO-PDgIkb82mZPEug&oe=6470EDFB"
      },
      {
        id: 2,
        pid: 1,
        name: "Angel Rick Enoria",
        title: "Manager",
        image: "https://z-p3-scontent.fmnl4-4.fna.fbcdn.net/v/t1.15752-9/341846900_947158773096815_5940605013816276771_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=ae9488&_nc_eui2=AeG5iyiPRj-TMY-dH13drEZQrKcWUZAUZe6spxZRkBRl7oNAgJuAi-UBz_qhs7rvPhuYWWKjjtqg7axj_bxA3t88&_nc_ohc=DixmXVZolJ8AX-hvyrT&_nc_ht=z-p3-scontent.fmnl4-4.fna&oh=03_AdTKj4ECeeWtwaBKSlBoPBYwJsmBfbi-eKnK9exN9IBIuQ&oe=6470E061"
      },
      {
        id: 3,
        pid: 1,
        name: "Christian Bendano",
        title: "Manager",
        image: "https://z-p3-scontent.fmnl4-4.fna.fbcdn.net/v/t1.15752-9/341898339_1190035491584704_8515316622998046702_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=ae9488&_nc_eui2=AeEBKGRV7gTwwcRpKBZ8qKkWCj5h7-CY_h8KPmHv4Jj-H51zTv8qqrmTqM-_9uba2GSMf5tYWVCp6mJu6TWWX6Nv&_nc_ohc=9HJb_H7B_bkAX9rRAHx&_nc_ht=z-p3-scontent.fmnl4-4.fna&oh=03_AdQJIzlT_64j52aotqXZjqRDwTAjRuLWpoD8TD0b2wXVVA&oe=6470EB5A"
      },
      {
        id: 4,
        pid: 1,
        name: "Joyce Clarisse Castillon",
        title: "Secretary",
        image: "https://z-p3-scontent.fmnl4-1.fna.fbcdn.net/v/t1.15752-9/341806574_255011570330844_5474702886890560659_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=ae9488&_nc_eui2=AeEqpJfBafkPikF_ytwFW8y1PZcf_y-0kJg9lx__L7SQmDEK2XRVqym7NZBYE6FVJnlBC9h8c3gjMl9T1QlqBJJW&_nc_ohc=qDApmlZsHwYAX8zfq24&_nc_ht=z-p3-scontent.fmnl4-1.fna&oh=03_AdQnsQqK47MF3xftTc-W4Y0GRMSQhIJgUsln_aumAzitZg&oe=6470DE26"
      },
      {
        id: 5,
        pid: 6,
        name: "Mart Jekko Tano",
        title: "Water Boy",
        image: "https://z-p3-scontent.fmnl4-6.fna.fbcdn.net/v/t1.15752-9/343534044_979227849759432_5718103038491814271_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=ae9488&_nc_eui2=AeEZCX79FvXZISdWMLxhtbkWCR_s5riv6m0JH-zmuK_qbY1iiOWvbQFQKmgrZv9MaKH_rsvAXXSNLknhF9qNOArJ&_nc_ohc=GAPw-W6w0N4AX_FFBh7&_nc_ht=z-p3-scontent.fmnl4-6.fna&oh=03_AdTbAOA0Wl76IzXbAQAV5WVu5Oi4duoRGrLms7mjeucD4Q&oe=6470E666"
      },
      {
        id: 6,
        pid: 3,
        name: "Rocell Oricio",
        title: "Coffee Maker",
        image: "https://z-p3-scontent.fmnl4-1.fna.fbcdn.net/v/t1.15752-9/340145969_1192346394782678_387350387742748270_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=ae9488&_nc_eui2=AeFFxAxDUKf_98HuYg47-CktAIzZpy5HVqsAjNmnLkdWq01wmce6uPCL0_hajmhyrBf6k6KamK2TrfHb066VkA1B&_nc_ohc=zUGIu08uUK8AX-TWoO3&_nc_ht=z-p3-scontent.fmnl4-1.fna&oh=03_AdRzWlOY9KS77OGmSEJ8TKrqxrvoIdN1IEG66RX4n1ZvEg&oe=6470B7F9"
      },
      {
        id: 7,
        pid: 6,
        name: "Ed Perpetua",
        title: "Janitor",
        image: "https://z-p3-scontent.fmnl4-6.fna.fbcdn.net/v/t1.15752-9/285914955_1188993421668986_5070697261935211462_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=ae9488&_nc_eui2=AeHwVpceJkSZbSiZwe85iNWGhzFy8gncBEiHMXLyCdwESFw36eHHoo65PmP-T0CNTj0JRQZyUC1WWnA80SPm2h6K&_nc_ohc=DGHWZPT8AKIAX830Wu-&_nc_ht=z-p3-scontent.fmnl4-6.fna&oh=03_AdQS31pgLOIq-ysPy3pvkGjdIMKT32REmE6RYN4rCAR6eA&oe=6470C6FB"
      }
    ];

    let orgChart = new OrgChart(document.getElementById("org"), {
      enableDragDrop: false,
      enableSearch: true,
      mode: "dark",
      nodes: nodes,
      nodeBinding: {
        field_0: "name",
        field_1: "title",
        img_0: "image"
      }
    });


    orgChart.on('click', function(sender, args) {
      return false
    });
    orgChart.draw();



    function addFileInput() {
      var requirements = document.getElementById("requirements");
      var inputGroup = document.createElement("div");
      inputGroup.classList.add("input-group", "mb-3");
      var inputFile = document.createElement("input");
      inputFile.type = "file";
      inputFile.classList.add("form-control");
      inputFile.name = "requirement[]";
      inputFile.accept = ".pdf,.doc,.docx";
      var button = document.createElement("button");
      button.classList.add("btn", "btn-outline-danger", "removeAtt");
      button.type = "button";
      var icon = document.createElement("i");
      icon.classList.add("fas", "fa-minus");
      button.appendChild(icon);
      inputGroup.appendChild(inputFile);
      inputGroup.appendChild(button);
      requirements.appendChild(inputGroup);
    }

    function removeElem() {
      for (let i = 0; i < document.querySelectorAll(".removeAtt").length; i++) {
        document.querySelectorAll(".removeAtt")[i].addEventListener('click', function(e) {
          var inputGroup = document.querySelectorAll(".removeAtt")[i].parentNode;
          inputGroup.parentNode.removeChild(inputGroup);
        })
      }
    }
    removeElem()
    document.querySelector("#addAtt").addEventListener("click", () => {
      addFileInput()
      removeElem()
    })


    codeReq("GET", "assets/backend/alljobs.php", (result) => {
      let x = JSON.parse(result)
      let jobs = document.querySelector("#job-list")
      jobs.innerHTML = ""
      for (let y = 0; y < x.length; y++) {
        jobs.innerHTML += ' <div class="col-md-4 mb-4">' +
          '<div class="card">' +
          '<div class="card-body">' +
          '<h5 class="card-title">' + '<p data-text="' + x[y].TITLE + '">' + x[y].TITLE + '</p>' +
          '</h5>' +
          '<p class="card-text">' + '<p data-text="' + x[y].DESC + '">' + x[y].DESC + '</p>' + '</p>' +
          '<ul class="list-group list-group-flush">' +
          '<li class="list-group-item">' +
          '<strong>Location:</strong>' +
          '<label class="ms-2" data-text="' + x[y].LOCATION + '">' + x[y].LOCATION + '</label>' + '</li>' +
          '<li class="list-group-item">' +
          '<strong>Salary:</strong>' +
          '<label class="ms-2" data-text="' + x[y].SALARY + '">' + x[y].SALARY + '</label>' +
          '</li>' +
          '<li class="list-group-item">' +
          '<strong>Requirements:</strong>' +
          '<p>SSS, PhilHealth, Pagibig, Health Certificate, Police Clearance</p>' +
          '</li>' +
          '</ul>' +
          '<button class="btn btn-primary job-btn card-link apply-btn mt-3" data-salary="' + x[y].SALARY + '" data-title="' + x[y].TITLE + '" data-type="' + x[y].TYPE + '" data-bs-toggle="modal" data-bs-target="#exampleModal">' +
          'Apply Now' +
          '</button></div></div></div>'
      }
      console.log(document.querySelectorAll(".job-btn").length)
      for (let i = 0; i < document.querySelectorAll(".job-btn").length; i++) {
        document.querySelectorAll(".job-btn")[i].addEventListener("click", () => {

          let salary = document.querySelectorAll(".job-btn")[i].getAttribute("data-salary")
          let jobtype = document.querySelectorAll(".job-btn")[i].getAttribute("data-type")
          let jobtitle = document.querySelectorAll(".job-btn")[i].getAttribute("data-title")
          console.log(salary)
          document.querySelector("#job-title-modal").innerHTML = jobtitle
          document.querySelector("#job-title-modal").setAttribute("data-job", jobtitle)
          // document.querySelector("#job-type-modal").innerHTML = jobtype
          document.querySelector("#salary-modal").innerHTML = salary

        })
      }
    })

    function checkInputs(Object, data) {
      var target = document.querySelector(Object).files[0]
      if (target.length === 0) {
        return false;
      } else {
        let docu = ["application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/pdf"]
        let profile = ["image/jpeg", "image/png"]
        if (data === 0) {
          for (let i = 0; i < profile.length; i++) {
            if (target.type === profile[i]) {
              return true
            }
          }
        } else {
          for (let i = 0; i < docu.length; i++) {
            if (target.type === docu[i]) {
              return true
            }
          }
        }

      }
      return false
    }

    function checkRequirements(Object) {
      let target = document.querySelectorAll(Object)
      let checker = []
      for (let i = 0; i < target.length; i++) {
        let data = target[i].files[0]
        checker.push(fileChecker(data.type))
        if (i === target.length - 1) {
          const fact = checker.every(Boolean);
          return fact
        }
      }
      return false
    }

    function fileChecker(data) {
      let file = ["image/jpeg", "image/png", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/pdf"]
      for (let i = 0; i < file.length; i++) {
        if (data === file[i]) {
          return true
        }
      }
      return false
    }
    document.querySelector("#sendForm").addEventListener("click", () => {
      try {
        if (checkInputs("#img", 0) && checkInputs("#resume", 1)) {
          if (document.querySelector("#date").value == "") {
            swal("C'mon", "Date is important", "warning");
          } else {
            if (checkRequirements("[name='requirement[]']")) {
              var formdata = new FormData(document.querySelector("#applying"))
              formdata.append("date", document.querySelector("#date").value)
              formdata.append("UID", sessionStorage.getItem("ID"))
              formdata.append("title", document.querySelector("#job-title-modal").getAttribute("data-job"))
              userReq("POST", "assets/backend/applicant.php", (result) => {
                console.log(result)
                let value = JSON.parse(result)
                if (value.Error === 1) {
                  swal("Sorry!", "Something went wrong", "error");
                } else {
                  swal("Success!", "Your application has been submitted", "success").then((result) => {
                    document.getElementById("exampleModal").style.display = "none"
                    var modalBackdrop = document.getElementsByClassName("modal-backdrop")[0];
                    modalBackdrop.parentNode.removeChild(modalBackdrop);
                  });
                }
              }, formdata)
            } else {
              swal("Oh no!", "Kindly check your form", "warning");
            }
          }
        } else {
          swal("Oh no!", "Only (PNG,JPG) for Picture and (PDF,DOCX) for Resume/CV", "warning");
        }


      } catch (TypeError) {
        swal("Oh no!", "Kindly check your form", "warning");
      }
    })
  </script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>

</html>