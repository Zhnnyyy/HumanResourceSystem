<!DOCTYPE html>
<html lang="en">

<head>
  <title>Responsive Sidebar</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
  <style>
    .sidebar {
      position: fixed;
      top: 0;
      left: -300px;
      width: 300px;
      height: 100%;
      background-color: #333;
      padding-top: 50px;
      overflow-x: hidden;
      /* z-index: 1; */
      /* transition: all 0.3s ease; */
      transition: 0.5s;
      /* background-color: #f8f9fa;
        height: 100%;
        position: fixed;
        top: 0;
        left: -200px;
        overflow-x: hidden;
        transition: 0.5s; */
    }

    .sidebar.show {
      left: 0;
    }

    #content {
      transition: 0.5s;
    }

    .sidebar.show~#content {
      margin-left: 300px;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .sidebar ul li {
      padding: 10px 0;
      border-top: 1px solid #666;
    }

    .sidebar ul li a {
      display: block;
      color: #fff;
      padding-left: 20px;
      font-size: 18px;
      text-decoration: none;
    }

    .sidebar ul li:hover {
      background-color: #555;
    }

    .sidebar ul li.active {
      background-color: #222;
    }

    .droplist .wrapper {
      float: right;
    }

    #menu-toggle {
      margin-top: 10px;
      /* margin-left: 10px; */
    }

    @media (max-width: 768px) {
      .sidebar {
        width: 100%;
        height: 100vh;
        position: relative;
        left: 0;
        margin-bottom: 30px;
      }

      .sidebar.show {
        margin-left: 0;
      }

      #content {
        margin-left: 0;
      }
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-2 sidebar" id="sidebar">
        <center>
          <div class="sidebar-header mb-5">
            <img src="images/logos.jpg" alt="" />
          </div>
        </center>
        <ul>
          <li class="active mlist" data-link="dashboard.html">
            <a href="#"><i class="fa fa-home"></i>Home</a>
          </li>
          <li class="mlist" data-link="applicant_table.html">
            <a href="#"><i class="fas fa-user-tag"></i>Applicant</a>
          </li>
          <li class="droplist">
            <a href="#" data-toggle="collapse" data-target="#job"><i class="fas fa-desktop"></i>Job
              <span class="wrapper"><i class="fas fa-caret-down"></i></span></a>
            <ul class="collapse" id="job">
              <li class="mlist" data-link="joboffers.html">
                <a href="#" class="ml-3"><i class="fas fa-file-alt"></i>Manage Job</a>
              </li>
            </ul>
          </li>
          <li class="droplist">
            <a href="#" data-toggle="collapse" data-target="#employee">
              <i class="fas fa-users"></i>Employee<span class="wrapper"><i class="fas fa-caret-down"></i></span>
            </a>
            <ul class="collapse" id="employee">
              <li class="mlist" data-link="addemployee.html">
                <a href="#" class="ml-3"><i class="fas fa-user-plus"></i>Add Employee</a>
              </li>
              <li class="mlist">
                <a href="#" class="ml-3"><i class="fas fa-user-cog"></i>Manage Employee</a>
              </li>
            </ul>
          </li>
          <li class="mlist">
            <a href="#"><i class="far fa-money-bill-alt"></i>Payroll</a>
          </li>
        </ul>
      </div>
      <div class="col-md-20" id="content">
        <button class="btn btn-primary" id="menu-toggle">
          Toggle Sidebar
        </button>
        <div class="container dash-content">
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin
            vitae odio sed ex porta tristique. Nam et nisi euismod, rhoncus
            turpis nec, molestie mi. Sed vel mi sit amet lacus tincidunt
            euismod. Ut facilisis mauris non massa molestie euismod. Aliquam
            accumsan, odio eget volutpat congue, enim nulla tristique turpis,
            vel finibus dolor leo in est. Sed auctor ex ac nulla eleifend,
            vitae maximus orci dignissim. Sed quis lectus consequat, gravida
            est in, lacinia felis. Nullam lacinia nisi nibh, quis viverra nibh
            sagittis eget.
          </p>
        </div>
      </div>
    </div>
  </div>
  <script src="assets/backend/main-scripting.js" type="module"></script>
  <script type="module">
    import {
      userReq
    } from "./assets/backend/main-scripting.js";
    document
      .querySelector("#menu-toggle")
      .addEventListener("click", showSidebar);

    function showSidebar() {
      document.querySelector("#sidebar").classList.toggle("show");
    }
    userReq("GET", "dashboard.html", (result) => {
      document.querySelector(".dash-content").innerHTML = result;
    });
    for (let i = 0; i < document.querySelectorAll(".mlist").length; i++) {
      document.querySelectorAll(".mlist")[i].addEventListener("click", () => {
        for (let x = 0; x < document.querySelectorAll(".mlist").length; x++) {
          if (x !== this) {
            document.querySelectorAll(".mlist")[x].classList.remove("active");
          }
        }
        document.querySelectorAll(".mlist")[i].classList.toggle("active");
        let data = document
          .querySelectorAll(".mlist")[i].getAttribute("data-link");
        userReq("GET", data, (result) => {
          document.querySelector(".dash-content").innerHTML = result;
          if (data.match("applicant_table.html")) {
            Applicant();
          } else if (data.match("joboffers.html")) {
            JobOffer();
          }
        });
      });
    }

    const Applicant = () => {
      userReq("GET", "assets/backend/pendingapplicant.php", (result) => {
        let x = JSON.parse(result);
        let count = 0;
        let tbl = document.querySelector("#tbl-content");
        tbl.innerHTML = "";
        for (let i = 0; i < x.length; i++) {
          count++;
          let element_link = "elem" + count;
          let name = x[i].fname + " " + x[i].lname;
          tbl.innerHTML +=
            " <tr>" +
            "<td>" +
            count +
            "</td>" +
            "<td>" +
            name +
            "</td>" +
            "<td>" +
            x[i].position +
            "</td>" +
            "<td>" +
            x[i].date +
            "</td>" +
            "<td>" +
            '<div class="btn-group">' +
            '<button type="button" class="toggle btn btn-primary view-pic"  data-target="#' +
            element_link +
            '" data-link="' +
            x[i].img +
            '" data-linktype="' +
            x[i].imgtype +
            '">' +
            '<i class="fas fa-image"></i>  Picture' +
            "</button>" +
            '<button type="button" class="toggle btn btn-success view-cv"  data-target="#' +
            element_link +
            '" data-link="' +
            x[i].cv +
            '"data-linktype="' +
            x[i].cvtype +
            '">' +
            '<i class="fas fa-file-alt"></i>  CV' +
            "</button>" +
            '<button data-link="' +
            x[i].id +
            '"' +
            'type="button"' +
            'class=" btn btn-info view-requirement"' +
            'data-toggle="collapse"' +
            'data-target="#' +
            element_link +
            '">' +
            '<i class="fa fa-list-alt"></i>  Requirements' +
            "</button>" +
            "</div>" +
            '<div  class="collapse zhen" id="' +
            element_link +
            '">' +
            '<ul id="require-list"> ' +
            "</ul>" +
            "</div>" +
            '<div class="btn-group lastbtn">' +
            '<button type="button" class="toggle btn btn-success accept-applicant"  data-target="#' +
            element_link +
            '">' +
            '<i class="fas fa-check"></i> ' +
            "</button>" +
            '<button type="button" class="toggle btn btn-danger reject-applicant"  data-target="#' +
            element_link +
            '">' +
            '<i class="fas fa-times"></i> ' +
            "</button>" +
            "</div>" +
            "</td>" +
            "</tr>";
        }

        function downloadFile(base64Data, fileName) {
          const link = document.createElement("a");
          link.href = URL.createObjectURL(base64ToBlob(base64Data));
          link.download = fileName;
          link.click();
        }

        function base64ToBlob(base64Data) {
          const byteString = atob(base64Data);
          const buffer = new ArrayBuffer(byteString.length);
          const array = new Uint8Array(buffer);
          for (let i = 0; i < byteString.length; i++) {
            array[i] = byteString.charCodeAt(i);
          }
          return new Blob([buffer], {
            type: "application/octet-stream",
          });
        }

        function getRotate() {
          var currentRotation = 0;
          document
            .getElementById("rotation")
            .addEventListener("click", function() {
              currentRotation += 90;
              document.querySelector("#img-viewsource").style.transform =
                "rotate(" + currentRotation + "deg)";
            });
        }

        for (
          let j = 0; j < document.querySelectorAll(".accept-applicant").length; j++
        ) {
          document
            .querySelectorAll(".accept-applicant")[j].addEventListener("click", () => {
              document.querySelector(".target-class");
              swal({
                title: "Are you sure?",
                text: "",
                icon: "warning",
                buttons: {
                  cancel: true,
                  confirm: "Confirm",
                },
              }).then((result) => {
                if (result) {
                  swal("Gotcha!", {
                    icon: "success",
                  }).then((result) => {
                    if (result) {}
                  });
                } else {}
              });
            });
        }

        for (
          let j = 0; j < document.querySelectorAll(".reject-applicant").length; j++
        ) {
          document
            .querySelectorAll(".reject-applicant")[j].addEventListener("click", () => {
              swal({
                title: "Are you sure?",
                text: "",
                icon: "warning",
                buttons: {
                  cancel: true,
                  confirm: "Confirm",
                },
              }).then((result) => {
                if (result) {
                  swal("Gotcha!", {
                    icon: "success",
                  }).then((result) => {
                    if (result) {}
                  });
                } else {}
              });
            });
        }

        for (
          let j = 0; j < document.querySelectorAll(".view-pic").length; j++
        ) {
          document
            .querySelectorAll(".view-pic")[j].addEventListener("click", () => {
              let file = document
                .querySelectorAll(".view-pic")[j].getAttribute("data-link");
              let linktype = document
                .querySelectorAll(".view-pic")[j].getAttribute("data-linktype");
              document
                .querySelectorAll(".view-pic")[j].setAttribute("data-toggle", "modal");
              document
                .querySelectorAll(".view-pic")[j].setAttribute("data-target", "#imagemodal");
              let uri = "data:" + linktype + ";base64," + file;
              document.querySelector("#img-viewsource").src = uri;
              getRotate();
            });
        }

        for (
          let j = 0; j < document.querySelectorAll(".view-cv").length; j++
        ) {
          document
            .querySelectorAll(".view-cv")[j].addEventListener("click", () => {
              let file = document
                .querySelectorAll(".view-cv")[j].getAttribute("data-link");
              let linktype = document
                .querySelectorAll(".view-cv")[j].getAttribute("data-linktype");
              let uri = "data:" + linktype + ";base64," + file;
              switch (linktype) {
                case "application/pdf":
                  window.open("fileviewer.php?id=" + link, "_blank");
                  break;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                  swal({
                    title: "Do you want to download instead?",
                    text: "The file you're requested is MsWord",
                    icon: "warning",
                    buttons: {
                      cancel: true,
                      confirm: "Confirm",
                    },
                  }).then((result) => {
                    if (result) {
                      swal("Gotcha!", {
                        icon: "success",
                      }).then((result) => {
                        if (result) {
                          downloadFile(file, "file.docx");
                        }
                      });
                    } else {}
                  });
                  break;
              }
            });
        }

        for (
          let j = 0; j < document.querySelectorAll(".view-requirement").length; j++
        ) {
          document
            .querySelectorAll(".view-requirement")[j].addEventListener("click", () => {
              // let datas = document.querySelectorAll(".toggle")[i].getAttribute("data-target")
              // document.querySelector(datas).style.display = "block"
              let req = document
                .querySelectorAll(".view-requirement")[j].getAttribute("data-link");
              let data = new FormData();
              data.append("ID", req);
              let parent =
                document.querySelectorAll("#require-list")[j].parentNode;
              let requirement = document.querySelectorAll("#require-list")[j];
              requirement.innerHTML = "";
              userReq(
                "POST",
                "assets/backend/showApplicantRequirements.php",
                (result) => {
                  let x = JSON.parse(result);
                  for (let i = 0; i < x.length; i++) {
                    requirement.innerHTML +=
                      '<li class="app-list ms-5">' +
                      '<a href="#" class="view-btn" data-link="' +
                      x[i].attachment +
                      '" data-linktype="' +
                      x[i].attachmenttype +
                      '" data-id="' +
                      x[i].ID +
                      '" >View</a>' +
                      "</li>";
                  }

                  for (
                    let k = 0; k < document.querySelectorAll(".view-btn").length; k++
                  ) {
                    document
                      .querySelectorAll(".view-btn")[k].addEventListener("click", () => {
                        let file = document
                          .querySelectorAll(".view-btn")[k].getAttribute("data-link");
                        let link = document
                          .querySelectorAll(".view-btn")[k].getAttribute("data-id");
                        let linktype = document
                          .querySelectorAll(".view-btn")[k].getAttribute("data-linktype");
                        switch (linktype) {
                          case "application/pdf":
                            window.open(
                              "fileviewer.php?id=" + link,
                              "_blank"
                            );
                            break;
                          case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                            swal({
                              title: "Do you want to download instead?",
                              text: "The file you're requested is MsWord",
                              icon: "warning",
                              buttons: {
                                cancel: true,
                                confirm: "Confirm",
                              },
                            }).then((result) => {
                              if (result) {
                                swal("Gotcha!", {
                                  icon: "success",
                                }).then((result) => {
                                  if (result) {
                                    downloadFile(file, "file.docx");
                                  }
                                });
                              } else {}
                            });
                            break;
                          case "image/png":
                          case "image/jpeg":
                          case "image/jpg":
                            document
                              .querySelectorAll(".view-btn")[k].setAttribute("data-toggle", "modal");
                            document
                              .querySelectorAll(".view-btn")[k].setAttribute("data-target", "#imagemodal");
                            let uri = "data:" + linktype + ";base64," + file;
                            document.querySelector("#img-viewsource").src =
                              uri;
                            getRotate();
                            break;
                        }
                      });
                  }
                },
                data
              );
            });
        }
      });
    };
  </script>
</body>

</html>