<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        #embedd {
            width: 100%;
            height: 900px;
        }
    </style>
</head>

<body>
    <embed id="embedd">
</body>
<script src="assets/backend/main-scripting.js" type="module"></script>
<script type="module">
    import {
        userReq
    } from "./assets/backend/main-scripting.js"
    let data = new FormData()
    const urlParams = new URLSearchParams(window.location.search);
    data.append("ID", urlParams.get("id"))

    userReq("POST", urlParams.get("key"), (result) => {
        let canvas = document.querySelector("#embedd")
        let x = JSON.parse(result)
        console.log()
        let uri = "data:" + x[0].type + ";base64," + x[0].content
        canvas.type = x[0].type
        canvas.src = uri
    }, data)
</script>

</html>