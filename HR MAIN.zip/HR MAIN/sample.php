<?php
session_start();
if (!$_SESSION['isLoggedIn']) {
    header("location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Neo-Core | Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" />
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            left: 0px;
            width: 250px;
            height: 100%;
            background-color: #333;
            padding-top: 10px;
            z-index: 1;
            transition: all 0.3s ease;
        }

        .sidebar-footer {
            position: absolute;
            bottom: 0;
            left: 0;
            margin-bottom: 20px;
            width: 100%;
        }


        /* .sidebar:hover {
            width: 300px;
        } */

        .sidebar .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar .logo img {
            width: 80%;
            max-width: 150px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar ul li {
            padding: 10px 0;
            border-top: 1px solid #666;
        }

        .sidebar ul li a {
            display: block;
            color: #fff;
            padding-left: 20px;
            font-size: 18px;
            text-decoration: none;
        }

        .sidebar ul li a i {
            margin-right: 10px;
        }

        .sidebar ul li:hover {
            background-color: #555;
        }

        .sidebar ul li.active {
            background-color: #222;
        }

        .uimg {
            height: 100px;
            width: 100px;
            border-radius: 100%;
        }

        .droplist .wrapper {
            float: right;
        }

        .lastbtn {
            margin-left: 10px;
        }

        .sidebar.collapsed {
            width: 0;
            transition: all 0.3s ease;
        }

        .sidebar.collapsed .logo,
        .sidebar.collapsed .sidebar-footer {
            display: none;
        }

        .toggle-sidebar {
            margin-left: 250px;
            transition: all 0.1s ease-in-out;
        }

        .close-toggle {
            margin-left: 0;
            transition: all 0.3s ease-in-out;
        }

        .sidebar.collapsed .toggle-sidebar {
            margin-left: 0px;
        }

        .sidebar.collapsed ul li a {
            padding-left: 0;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
        }

        .sidebar.collapsed ul li a i {
            margin-right: 0;
        }

        .dash-content {
            margin-left: 70px;
        }

        .toggle-sidebar {
            position: absolute;
            top: 10px;
            left: 10px;
            z-index: 2;
        }

        .present {
            background-color: #90EE90;
        }

        .absent {
            background-color: #ff726f;
        }

        .leave {
            background-color: yellow;
        }

        .late {
            background-color: #FFD580;
            text-align: center;
        }

        .legends {
            font-size: large;
            background-color: #333;
            width: 100%;
        }

        .legends h4 {
            color: white;
        }

        .present-txt {
            color: #90EE90;
        }

        .leave-txt {
            color: yellow;
        }

        .late-txt {
            color: #FFD580;
        }

        .absent-txt {
            color: #ff726f;
        }
    </style>
</head>

<body id="dashboardbody">
    <div class="sidebar menu">
        <div class="logo">
            <!-- <img src="images/Logo.png" width="50px" height="75px" alt="Logo"> -->
            <h5 class="text-light">NEO-CORE</h5>
            <h6 class="text-light" id="user-name"></h6>
            <br>
            <img class="uimg" src="images/Logo.png" alt="">
        </div>
        <ul>
            <li class="droplist" id="admin-controls">
                <a href="#" data-toggle="collapse" data-target="#controls-admin">
                    <i class="fas fa-users-cog"></i>Admin Controls<span class="wrapper"><i class="fas fa-caret-down"></i></span>
                </a>
                <ul class="collapse" id="controls-admin">
                    <li class="mlist" data-link="admin_manage_employee.html"><a href="#" class="ml-4"><i class="fas fa-user-plus"></i>Manage Employee</a></li>
                    <li class="mlist" data-link="underdevelop.html"><a href="#" class="ml-4"><i class="fas fa-user-plus"></i>Add Employee</a></li>
                </ul>
            </li>
            <li class="active mlist" data-link="dashboard.html"><a href="#"><i class="fa fa-home"></i>Home</a></li>
            <li class="mlist" data-link="applicant_table.html"><a href="#"><i class="fas fa-user-tag"></i>Applicant</a></li>
            <li class="droplist"><a href="#" data-toggle="collapse" data-target="#job"><i class="fas fa-desktop"></i>Job <span class="wrapper"><i class="fas fa-caret-down"></i></span></a>
                <ul class="collapse" id="job">
                    <li class="mlist" data-link="joboffers.html"><a href="#" class="ml-4"><i class="fas fa-file-alt"></i>Manage Job Offer</a></li>
                </ul>
            </li>
            <li class="droplist">
                <a href="#" data-toggle="collapse" data-target="#attendance">
                    <i class="fas fa-clipboard-list"></i>Attendance<span class="wrapper"><i class="fas fa-caret-down"></i></span>
                </a>
                <ul class="collapse" id="attendance">
                    <li class="mlist" data-link="attendancelist.html"><a href="#" class="ml-4"><i class="far fa-list-alt"></i>Attendance Log</a></li>
                    <li class="mlist" data-link="attendanceReports.html"><a href="#" class="ml-4"><i class="fas  fa-flag"></i>Attendance Report</a></li>
                </ul>
            </li>
            <li class="droplist">
                <a href="#" data-toggle="collapse" data-target="#employee">
                    <i class="fas fa-users"></i>Employee<span class="wrapper"><i class="fas fa-caret-down"></i></span>
                </a>
                <ul class="collapse" id="employee">
                    <li class="mlist" data-link="addemployee.html"><a href="#" class="ml-4"><i class="fas fa-user-plus"></i>Add Employee</a></li>
                    <li class="mlist" data-link="manageEmployee.html"><a href="#" class="ml-4"><i class="fas fa-user-cog"></i>Manage Employee</a></li>
                </ul>
            </li>
            <li class="droplist">
                <a href="#" data-toggle="collapse" data-target="#employee_request">
                    <i class="fas fa-comments"></i>Employee Request<span class="wrapper"><i class="fas fa-caret-down"></i></span>
                </a>
                <ul class="collapse" id="employee_request">
                    <li class="mlist" data-link="employeerequest.html"><a href="#" class="ml-4"><i class="fas fa-comments"></i>Pending Request</a></li>
                    <li class="mlist" data-link="requestlog.html"><a href="#" class="ml-4"><i class="fas fa-comments"></i>Request Log</a></li>
                </ul>
            </li>
            <li class="droplist">
                <a href="#" data-toggle="collapse" data-target="#payroll">
                    <i class="far fa-money-bill-alt"></i>Payroll<span class="wrapper"><i class="fas fa-caret-down"></i></span>
                </a>
                <ul class="collapse" id="payroll">
                    <li class="mlist" data-link="underdevelop.html"><a href="#" class="ml-4"><i class="far fa-money-bill-alt"></i>Generate Payroll</a></li>
                    <li class="mlist" data-link="underdevelop.html"><a href="#" class="ml-4"><i class="far fa-money-bill-alt"></i>Payroll Logs</a></li>
                </ul>
            </li>
        </ul>
        <div class="sidebar-footer">
            <button class="btn btn-danger btn-block" id="signout"><i class="fas fa-sign-out-alt"></i> Sign out</button>
        </div>
    </div>




    <div class="modal fade" id="imagemodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <img id="img-viewsource" class="img-fluid mx-auto d-block" alt="modal-image" />
                </div>
                <div class="modal-footer">
                    <button id="rotation" class="btn btn-secondary"><i class="fas fa-sync"></i></button>
                </div>
            </div>
        </div>
    </div>
    <div class=" mt-5 dash-content" id="dash-content" style="margin-left: 250px;">

    </div>

    <!-- JavaScript Files -->
    <script src="assets/backend/main-scripting.js" type="module"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js"></script>
    <script type="module">
        import {
            userReq
        } from "./assets/backend/main-scripting.js"

        window.onload = function() {
            var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
            if (isMobile) {
                swal("Sorry!", "The developer of this site is not allowing you to open this in mobile", "warning").then((result) => {
                    if (result) {
                        document.querySelector("#dashboardbody").style.display = "none"
                    }
                    document.querySelector("#dashboardbody").style.display = "none"
                })
            }
        };

        document.querySelector("#signout").addEventListener("click", () => {
            swal({
                title: "Are you sure?",
                text: "You want to logout",
                icon: "warning",
                buttons: {
                    cancel: true,
                    confirm: "Okay"
                }
            }).then((result) => {
                if (result) {
                    sessionStorage.clear()
                    window.location.href = "login.php"
                }
            })
        })

        let isAdmin = <?= $_SESSION['isAdmin']; ?>;
        // console.log(sessionStorage.getItem("admin"))
        if (isAdmin) {
            document.querySelector("#admin-controls").style.display = "block"
        } else {
            document.querySelector("#admin-controls").style.display = "none"
        }
        document.querySelector("#user-name").innerHTML = sessionStorage.getItem("Name")



        userReq("GET", "dashboard.html", (result) => {
            document.querySelector(".dash-content").innerHTML = result

        })
        for (let i = 0; i < document.querySelectorAll(".mlist").length; i++) {
            document.querySelectorAll(".mlist")[i].addEventListener('click', () => {
                for (let x = 0; x < document.querySelectorAll(".mlist").length; x++) {
                    if (x !== this) {
                        document.querySelectorAll(".mlist")[x].classList.remove("active");
                    }
                }
                document.querySelectorAll(".mlist")[i].classList.toggle("active")
                let data = document.querySelectorAll(".mlist")[i].getAttribute("data-link")
                userReq("GET", data, (result) => {
                    document.querySelector(".dash-content").innerHTML = result
                    if (data.match("applicant_table.html")) {
                        Applicant()
                    } else if (data.match("joboffers.html")) {
                        JobOffer()
                    } else if (data.match("addemployee.html")) {
                        hireEmployees()
                    } else if (data.match("manageEmployee.html")) {
                        manageEmployees()
                    } else if (data.match("attendancelist.html")) {
                        attendanceList()
                    } else if (data.match("attendanceReports.html")) {
                        attendanceReport()
                    } else if (data.match("employeerequest.html")) {
                        employeeRequest()
                    } else if (data.match("requestlog.html")) {
                        requestLog()
                    } else if (data.match("admin_manage_employee.html")) {
                        admin_manage_emp()
                    }

                })
            })
        }

        const admin_manage_emp = () => {
            $(document).ready(function() {
                $("#admin-manage-employee").DataTable({
                    columnDefs: [{
                            width: '5%',
                            targets: 0
                        }, {
                            width: '10%',
                            targets: 1
                        },
                        {
                            width: '15%',
                            targets: 2
                        }, {
                            width: '15%',
                            targets: 3
                        }, {
                            width: '8%',
                            targets: 4
                        }, {
                            width: '10%',
                            targets: 5
                        }, {
                            width: '17%',
                            targets: 6
                        }, {
                            width: '18%',
                            targets: 7
                        }

                    ]
                });
            });

            loadAdminMngEmpTbl()

            function loadAdminMngEmpTbl() {
                userReq("GET", "assets/backend/adminManageEmployee.php", (result) => {
                    var adminMangetbl = $("#admin-manage-employee").DataTable()
                    adminMangetbl.clear().draw()
                    let x = JSON.parse(result)
                    let count = 0
                    for (let i = 0; i < x.length; i++) {
                        count++
                        let name = x[i].FNAME + " " + x[i].LNAME
                        let buttonHtml = '<div class="btn-group lastbtn">' +
                            '<button type="button" class="toggle btn btn-primary send-email" data-email="' + x[i].EMAIL + '"    >' +
                            '<i class="fas fa-paper-plane"></i>' +
                            '</button>' +
                            '</div>' +
                            '<div class="btn-group lastbtn">' +
                            '<button type="button" class="toggle btn btn-success view-details" data-dept="' + x[i].DEPT + '" data-shift="' + x[i].SHIFT + '" data-postype="' + x[i].POSTYPE + '" data-position="' + x[i].POS + '" data-date="' + x[i].DATE + '" data-email="' + x[i].EMAIL + '" data-bday="' + x[i].BDAY + '" data-gender="' + x[i].GENDER + '" data-lname="' + x[i].LNAME + '" data-fname="' + x[i].FNAME + '" data-mname="' + x[i].MNAME + '" data-toggle="modal" data-target="#admin-employee" data-id="' + x[i].EMPID + '">' +
                            '<i class="fas fa-edit"></i> ' +
                            '</button>' +
                            '<button type="button" class="toggle btn btn-info view-document" data-id="' + x[i].KEYID + '" >' +
                            '<i class="fas fa-folder-open"></i>cv ' +
                            '</button>' +
                            '</div>'
                        adminMangetbl.row.add([count, x[i].EMPID, name, x[i].POS, x[i].POSTYPE, x[i].SHIFT, x[i].DEPT, buttonHtml]).draw()
                    }
                    for (let i = 0; i < document.querySelectorAll(".send-email").length; i++) {
                        document.querySelectorAll(".send-email")[i].addEventListener("click", () => {
                            let data = new FormData()
                            data.append("email", document.querySelectorAll(".send-email")[i].getAttribute("data-email"))
                            swal("Send message to: " + data.get("email"), {
                                    content: "input",
                                })
                                .then((value) => {
                                    if (value) {
                                        data.append("msg", value)
                                        userReq("POST", "assets/backend/otp/adminmail.php", (result) => {
                                            if (!JSON.parse(result)[0].Error) {
                                                swal("Success!", "Email has been sent", "success")
                                            } else {
                                                swal("Oh no!", "Something went wrong", "error")
                                            }
                                        }, data)
                                    }
                                });
                        })
                    }

                    for (let i = 0; i < document.querySelectorAll(".view-details").length; i++) {
                        document.querySelectorAll(".view-details")[i].addEventListener("click", () => {
                            loadItems()
                            let dept = document.querySelectorAll(".view-details")[i].getAttribute("data-dept").trim()
                            let shift = document.querySelectorAll(".view-details")[i].getAttribute("data-shift").trim()
                            let pos = document.querySelectorAll(".view-details")[i].getAttribute("data-postype").trim()
                            let postype = document.querySelectorAll(".view-details")[i].getAttribute("data-position").trim()
                            let date = document.querySelectorAll(".view-details")[i].getAttribute("data-date")
                            let email = document.querySelectorAll(".view-details")[i].getAttribute("data-email")
                            let bday = document.querySelectorAll(".view-details")[i].getAttribute("data-bday")
                            let gender = document.querySelectorAll(".view-details")[i].getAttribute("data-gender")
                            let lname = document.querySelectorAll(".view-details")[i].getAttribute("data-lname")
                            let fname = document.querySelectorAll(".view-details")[i].getAttribute("data-fname")
                            let mname = document.querySelectorAll(".view-details")[i].getAttribute("data-mname")
                            let id = document.querySelectorAll(".view-details")[i].getAttribute("data-id")

                            document.querySelector("#doh").innerHTML = date
                            document.querySelector("#firstname").value = fname
                            document.querySelector("#middlename").value = mname
                            document.querySelector("#lastname").value = lname
                            document.querySelector("#email").value = email
                            document.querySelector("#bday").value = bday
                            document.querySelector("#gender").value = gender
                            document.querySelector("#position").value = document.querySelectorAll(".view-details")[i].getAttribute("data-postype")
                            document.querySelector("#emptype").value = document.querySelectorAll(".view-details")[i].getAttribute("data-position")
                            document.querySelector("#shift").value = document.querySelectorAll(".view-details")[i].getAttribute("data-shift")
                            document.querySelector("#department").value = document.querySelectorAll(".view-details")[i].getAttribute("data-dept")

                            document.querySelector("#submit-changes").addEventListener("click", () => {
                                let data = new FormData()
                                let pos = document.querySelector("#position")
                                let type = document.querySelector("#emptype")
                                let shift = document.querySelector("#shift")
                                let dept = document.querySelector("#department")
                                data.append("id", id)
                                data.append("fname", document.querySelector("#firstname").value)
                                data.append("mname", document.querySelector("#middlename").value)
                                data.append("lname", document.querySelector("#lastname").value)
                                data.append("email", document.querySelector("#email").value)
                                data.append("bday", document.querySelector("#bday").value)
                                data.append("gender", document.querySelector("#gender").value)
                                data.append("pos", pos.options[pos.selectedIndex].dataset.id)
                                data.append("type", type.options[type.selectedIndex].dataset.id)
                                data.append("shift", shift.options[shift.selectedIndex].dataset.id)
                                data.append("dept", dept.options[dept.selectedIndex].dataset.id)
                                swal({
                                    title: "Are you sure?",
                                    text: "This can't be undone",
                                    icon: "warning",
                                    buttons: {
                                        cancel: true,
                                        confirm: "Yes"
                                    }
                                }).then((result) => {
                                    if (result) {
                                        userReq("POST", "assets/backend/updateAdminEmp.php", (result) => {
                                            try {
                                                if (!JSON.parse(result).Error) {
                                                    swal("Success!", "User has been updated", "success").then((result) => {
                                                        document.getElementById("admin-employee").style.display = "none"
                                                        var modalBackdrop = document.getElementsByClassName("modal-backdrop")[0];
                                                        modalBackdrop.parentNode.removeChild(modalBackdrop);
                                                        loadAdminMngEmpTbl()
                                                    })

                                                } else {
                                                    swal("Error!", "Something went wrong", "error")
                                                }
                                            } catch (Error) {
                                                swal("Error!", "Email already existed", "error")
                                            }
                                        }, data)
                                    }
                                })

                            })
                        })
                    }
                    for (let i = 0; i < document.querySelectorAll(".view-document").length; i++) {
                        document.querySelectorAll(".view-document")[i].addEventListener("click", () => {
                            let id = document.querySelectorAll(".view-document")[i].getAttribute("data-id")
                            let data = new FormData()
                            data.append("id", id)
                            userReq("POST", "assets/backend/admincv.php", (result) => {
                                let x = JSON.parse(result)
                                if (!x.Error) {
                                    switch (x.type) {
                                        case "application/pdf":
                                            downloadFile(x.data, "user.pdf")
                                            break
                                        case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                                            downloadFile(x.data, "user.docx")
                                            break

                                    }
                                } else {
                                    swal("Sorry!", "Something went wrong", "error")
                                }
                            }, data)




                            function downloadFile(base64Data, fileName) {
                                const link = document.createElement("a");
                                link.href = URL.createObjectURL(base64ToBlob(base64Data));
                                link.download = fileName;
                                link.click();
                            }

                            function base64ToBlob(base64Data) {
                                const byteString = atob(base64Data);
                                const buffer = new ArrayBuffer(byteString.length);
                                const array = new Uint8Array(buffer);
                                for (let i = 0; i < byteString.length; i++) {
                                    array[i] = byteString.charCodeAt(i);
                                }
                                return new Blob([buffer], {
                                    type: "application/octet-stream"
                                });
                            }

                        })
                    }

                    function loadItems() {
                        userReq("GET", "assets/backend/loaddropdown.php", (result) => {
                            let x = JSON.parse(result)
                            let position = document.querySelector("#position")
                            let emptype = document.querySelector("#emptype")
                            let dept = document.querySelector("#department")
                            let shift = document.querySelector("#shift")
                            position.innerHTML = ""
                            emptype.innerHTML = ""
                            dept.innerHTML = ""
                            shift.innerHTML = ""
                            for (let i = 0; i < x[0].Department.length; i++) {
                                dept.innerHTML += '<option value="' + x[0].Department[i].Name + '" data-id="' + x[0].Department[i].ID + '" >' + x[0].Department[i].Name + '</option>'
                            }
                            for (let i = 0; i < x[1].WorkShift.length; i++) {
                                shift.innerHTML += '<option value="' + x[1].WorkShift[i].Name + '" data-id="' + x[1].WorkShift[i].ID + '">' + x[1].WorkShift[i].Name + '</option>'
                            }
                            for (let i = 0; i < x[2].EmploymentType.length; i++) {
                                emptype.innerHTML += '<option value="' + x[2].EmploymentType[i].Name + '" data-id="' + x[2].EmploymentType[i].ID + '">' + x[2].EmploymentType[i].Name + '</option>'
                            }
                            for (let i = 0; i < x[3].JobPosition.length; i++) {
                                position.innerHTML += '<option value="' + x[3].JobPosition[i].Name + '" data-id="' + x[3].JobPosition[i].ID + '">' + x[3].JobPosition[i].Name + '</option>'
                            }
                        })
                    }
                })
            }
        }

        const requestLog = () => {
            $(document).ready(function() {
                $("#request-log").DataTable({
                    columnDefs: [{
                            width: '5%',
                            targets: 0
                        }, {
                            width: '10%',
                            targets: 1
                        },
                        {
                            width: '20%',
                            targets: 2
                        }, {
                            width: '13%',
                            targets: 3
                        }, {
                            width: '11%',
                            targets: 4
                        }, {
                            width: '10%',
                            targets: 5
                        }, {
                            width: '10%',
                            targets: 6
                        }, {
                            width: '27%',
                            targets: 7
                        }

                    ]
                });
            });
            loadRequestLog()

            function loadRequestLog() {
                userReq("GET", "assets/backend/request_log.php", (result) => {
                    var request_log = $('#request-log').DataTable();
                    request_log.clear().draw();
                    let x = JSON.parse(result)
                    let count = 0
                    for (let i = 0; i < x.length; i++) {
                        count++
                        request_log.row.add([count, x[i].ID, x[i].NAME, x[i].TYPE, x[i].START, x[i].END, x[i].DATE, x[i].STATUS]).draw()
                    }
                })
            }
        }

        const employeeRequest = () => {
            $(document).ready(function() {
                $("#employee-request").DataTable({
                    columnDefs: [{
                            width: '5%',
                            targets: 0
                        }, {
                            width: '10%',
                            targets: 1
                        },
                        {
                            width: '20%',
                            targets: 2
                        }, {
                            width: '13%',
                            targets: 3
                        }, {
                            width: '11%',
                            targets: 4
                        }, {
                            width: '10%',
                            targets: 5
                        }, {
                            width: '10%',
                            targets: 6
                        }, {
                            width: '27%',
                            targets: 7
                        }

                    ]
                });
            });
            loadRequest()

            function loadRequest() {
                userReq("GET", "assets/backend/show_pending_request.php", (result) => {
                    var employee_request = $('#employee-request').DataTable();
                    employee_request.clear().draw();
                    let x = JSON.parse(result)
                    let count = 0

                    for (let i = 0; i < x.length; i++) {
                        count++
                        let buttonHtml = '<div class="btn-group lastbtn">' +
                            '<button type="button" class="toggle btn btn-primary view-msg" data-msg="' + x[i].MESSAGE + '" data-name="' + x[i].NAME + '"   >' +
                            '<i class="fas fa-comment-dots"></i>' +
                            '</button>' +
                            '</div>' +
                            '<div class="btn-group lastbtn">' +
                            '<button type="button" class="toggle btn btn-success accept-request" data-type="' + x[i].TYPE + '" data-link="' + x[i].REQID + '" data-start="' + x[i].START + '" data-end="' + x[i].END + '" data-id="' + x[i].ID + '"  >' +
                            '<i class="fas fa-check"></i> ' +
                            '</button>' +
                            '<button type="button" class="toggle btn btn-danger reject-request" data-link="' + x[i].REQID + '"  >' +
                            '<i class="fas fa-times"></i> ' +
                            '</button>' +
                            '</div>'

                        employee_request.row.add([count, x[i].ID, x[i].NAME, x[i].TYPE, x[i].START, x[i].END, x[i].DATE, buttonHtml]).draw()
                    }

                    for (let i = 0; i < document.querySelectorAll(".view-msg").length; i++) {
                        document.querySelectorAll(".view-msg")[i].addEventListener("click", (e) => {
                            let msg = document.querySelectorAll(".view-msg")[i].getAttribute("data-msg")
                            let name = document.querySelectorAll(".view-msg")[i].getAttribute("data-name")
                            swal({
                                title: name,
                                text: msg,
                            });
                        })
                    }

                    for (let i = 0; i < document.querySelectorAll(".accept-request").length; i++) {
                        document.querySelectorAll(".accept-request")[i].addEventListener("click", () => {
                            let id = document.querySelectorAll(".accept-request")[i].getAttribute("data-link")
                            let startdate = document.querySelectorAll(".accept-request")[i].getAttribute("data-start")
                            let endDate = document.querySelectorAll(".accept-request")[i].getAttribute("data-end")
                            let empID = document.querySelectorAll(".accept-request")[i].getAttribute("data-id")
                            let requestType = document.querySelectorAll(".accept-request")[i].getAttribute("data-type")
                            swal({
                                    title: "Are you sure?",
                                    text: "You want to accept this request",
                                    icon: "warning",
                                    buttons: {
                                        cancel: true,
                                        confirm: "Confirm"
                                    }

                                })
                                .then((result) => {
                                    if (result) {
                                        let formdata = new FormData()
                                        formdata.append("id", id)
                                        formdata.append("status", "accepted")
                                        userReq("POST", "assets/backend/updaterequest.php", (result) => {
                                            let x = JSON.parse(result)

                                            if (!x.Error) {
                                                swal("Success!", "Request has been accepted", "success")
                                                startAttendance(startdate, endDate, empID, requestType)
                                                loadRequest()

                                            }
                                        }, formdata)
                                    } else {

                                    }
                                });
                        })


                    }

                    function startAttendance(startdate, enddate, empid, requestType) {
                        var startDateObj = new Date(startdate);
                        var endDateObj = new Date(enddate);


                        var currentDate = startDateObj;
                        while (currentDate <= endDateObj) {
                            setAttendance(empid, currentDate.toISOString().slice(0, 10))
                            currentDate.setDate(currentDate.getDate() + 1);
                        }
                        swal("Notice!", "Attendance has been set", "success").then((result) => {
                            if (result) {
                                updateCredits(empid, requestType)
                            } else {
                                updateCredits(empid, requestType)
                            }
                        })


                    }

                    function updateCredits(ID, type) {
                        let data = new FormData()
                        data.append("id", ID)
                        data.append("tbl", type)

                        userReq("POST", "assets/backend/updateCredits.php", (result) => {
                            let x = JSON.parse(result)
                            if (!x.Error) {
                                swal("Success!", "Leave credits has been updated", "success")
                            } else {
                                swal("Sorry!", "Something went wrong", "error")
                            }
                        }, data)
                    }

                    function setAttendance(empid, date) {
                        let formdata = new FormData()
                        formdata.append("id", empid)
                        formdata.append("date", date)
                        userReq("POST", "assets/backend/setAttendance.php", (result) => {}, formdata)
                    }

                    for (let i = 0; i < document.querySelectorAll(".reject-request").length; i++) {
                        document.querySelectorAll(".reject-request")[i].addEventListener("click", () => {
                            let id = document.querySelectorAll(".reject-request")[i].getAttribute("data-link")
                            swal({
                                    title: "Are you sure?",
                                    text: "You want to reject this request",
                                    icon: "warning",
                                    buttons: {
                                        cancel: true,
                                        confirm: "Confirm"
                                    }

                                })
                                .then((result) => {
                                    if (result) {
                                        let formdata = new FormData()
                                        formdata.append("id", id)
                                        formdata.append("status", "rejected")
                                        userReq("POST", "assets/backend/updaterequest.php", (result) => {
                                            let x = JSON.parse(result)
                                            if (!x.Error) {
                                                swal("Success!", "Request has been rejected", "success")
                                                loadRequest()
                                            }
                                        }, formdata)
                                    } else {

                                    }
                                });
                        })
                    }



                })
            }
        }

        const attendanceReport = () => {
            $(document).ready(function() {
                $("#attendancereporttbl").DataTable({
                    columnDefs: [{
                            width: '5%',
                            targets: 0
                        }, {
                            width: '12%',
                            targets: 1
                        },
                        {
                            width: '20%',
                            targets: 2
                        }, {
                            width: '15%',
                            targets: 3
                        }, {
                            width: '10%',
                            targets: 4
                        }, {
                            width: '15%',
                            targets: 5
                        }, {
                            width: '10%',
                            targets: 6
                        }, {
                            width: '10%',
                            targets: 7
                        }

                    ]
                });
            });
            loadingtable()

            function loadingtable() {
                loadReporttbl()
                let urlToProxy = 'http://neocore-zhn.orgfree.com/assets/backend/showAllEmployee.php';
                let proxyUrl = 'http://neocore-zhn.orgfree.com/assets/backend/mproxy.php?url=' + encodeURIComponent(urlToProxy);
                var xhr = new XMLHttpRequest();
                xhr.open('GET', proxyUrl, true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        var result = xhr.responseText;
                        var table = $('#attendancereporttbl').DataTable();
                        table.clear().draw();
                        console.log(result)
                        let x = JSON.parse(result)
                        let count = 0
                        console.log(result)
                        for (let i = 0; i < x.length; i++) {
                            count++
                            let buttonsHtml = '<div class="btn-group">' +
                                '<button class="btn btn-primary viewBtn" data-id="' + x[i].ID + '"  "><i class="fas fa-eye"></i> view</button>' +
                                '</div>'
                            let name = x[i].fname + ' ' + x[i].lname
                            table.row.add([count, x[i].ID, name, x[i].posName, x[i].empType, x[i].dept, x[i].shift, buttonsHtml]).draw()
                        }

                        for (let i = 0; i < document.querySelectorAll(".viewBtn").length; i++) {
                            document.querySelectorAll(".viewBtn")[i].addEventListener("click", (e) => {
                                let id = e.target.getAttribute("data-id")
                                let start_month = document.querySelector("#start-date-attendancereport").value
                                let end_month = document.querySelector("#end-date-attendancereport").value
                                let formdata = new FormData()
                                formdata.append("ID", id)
                                formdata.append("startdate", start_month)
                                formdata.append("enddate", end_month)
                                if (start_month === "" || end_month === "") {
                                    swal("Sorry!", "Please provide start and end date", "warning")
                                } else {
                                    const modal = document.getElementById('reportModal');
                                    const bootstrapModal = new bootstrap.Modal(modal);
                                    bootstrapModal.show();
                                    userReq("POST", "assets/backend/attendancereport.php", (result) => {
                                        let x = JSON.parse(result)
                                        generateCalendar(x, start_month, end_month)
                                    }, formdata)
                                }


                            })
                        }




                    }
                };

                xhr.send();
            }

     


            function generateCalendar(attendanceRecords, startmonth, endmonth) {
                var calendarRow = document.querySelector("#calendarRow");
                var currentYear = startmonth.split("-")[0];
                var startMonth = new Date(startmonth).getMonth() + 1;
                var endMonth = new Date(endmonth).getMonth() + 1;


                var calendarHTML = "";
                for (var month = startMonth; month <= endMonth; month++) {
                    var startDate = new Date(currentYear, month - 1, 1);
                    var endDate = new Date(currentYear, month, 0);
                    var currentDate = startDate;

                    calendarHTML += '<div class="col-md-4">';
                    calendarHTML +=
                        "<h3>" +
                        currentDate.toLocaleString("default", {
                            month: "long"
                        }) +
                        "</h3>";

                    calendarHTML += '<table class="mini-calendar table table-bordered">';
                    calendarHTML +=
                        "<thead><tr><th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th></tr></thead>";
                    calendarHTML += "<tbody>";

                    while (currentDate <= endDate) {
                        calendarHTML += "<tr>";

                        for (var i = 0; i < 7; i++) {
                            if (currentDate.getMonth() + 1 === month) {
                                calendarHTML += "<td";

                                var dateStr = formatDate(currentDate);

                                var attendanceRecord = attendanceRecords.find(
                                    (record) => record.date === dateStr
                                );
                                if (attendanceRecord) {
                                    var status = attendanceRecord.status;
                                    calendarHTML += ' class="' + status + '"';
                                }

                                calendarHTML += ">" + currentDate.getDate() + "</td>";
                            } else {
                                calendarHTML += "<td></td>";
                            }

                            currentDate.setDate(currentDate.getDate() + 1);
                        }

                        calendarHTML += "</tr>";
                    }

                    calendarHTML += "</tbody></table>";
                    calendarHTML += "</div>";
                }

                calendarRow.innerHTML = calendarHTML;
            }

            function formatDate(date) {
                var year = date.getFullYear();
                var month = date.getMonth() + 1;
                var day = date.getDate();

                if (month < 10) {
                    month = "0" + month;
                }

                if (day < 10) {
                    day = "0" + day;
                }

                return year + "-" + month + "-" + day;
            }

        }

        const attendanceList = () => {
            loadTables()
            $(document).ready(function() {
                $("#example").DataTable({
                    columnDefs: [{
                            width: '5%',
                            targets: 0
                        }, {
                            width: '15%',
                            targets: 1
                        },
                        {
                            width: '25%',
                            targets: 2
                        }, {
                            width: '10%',
                            targets: 3
                        }, {
                            width: '10%',
                            targets: 4
                        }, {
                            width: '10%',
                            targets: 5
                        }, {
                            width: '10%',
                            targets: 6
                        }

                    ]
                });
            });

            function loadTables() {
                let count = 0
                userReq("GET", "assets/backend/attendance.php", (result) => {
                    let x = JSON.parse(result)
                    var table = $('#example').DataTable();
                    table.clear().draw();
                    console.log(result)
                    for (let i = 0; i < x.length; i++) {
                        count++
                        // let time_in = (x[i].TIMEIN === null) ? null : time_in = convertTimeFormat(x[i].TIMEIN)
                        // let time_out = (x[i].TIMEOUT === null) ? null : time_out = convertTimeFormat(x[i].TIMEOUT)
                        let time_in = ""
                        let time_out = ""
                        let wrkhrs = ""
                        if (x[i].TIMEIN === null) {
                            time_in = "null"
                        } else {
                            time_in = convertTimeFormat(x[i].TIMEIN)
                        }
                        if (x[i].TIMEOUT === null) {
                            time_out = "No data"
                        } else {
                            time_out = convertTimeFormat(x[i].TIMEOUT)
                        }
                        if (x[i].WORKHRS === null) {
                            wrkhrs = "No data"
                        } else {
                            wrkhrs = convertTimeFormat(x[i].WORKHRS)
                        }
                        table.row.add([count, x[i].ID, x[i].NAME, time_in, time_out, wrkhrs, x[i].DATE]).draw()
                    }
                })
            }
            document.querySelector("#end-date-attendance").addEventListener("change", () => {
                let formdata = new FormData()
                formdata.append("startdate", document.querySelector("#start-date-attendance").value)
                formdata.append("enddate", document.querySelector("#end-date-attendance").value)
                if (document.querySelector("#end-date-attendance").value === "") {
                    document.querySelector("#start-date-attendance").value === ""
                    loadTables()
                } else {
                    let count = 0
                    userReq("POST", "assets/backend/attendancefiltered.php", (result) => {
                        let x = JSON.parse(result)
                        var table = $('#example').DataTable();
                        table.clear().draw();

                        for (let i = 0; i < x.length; i++) {
                            count++
                            let time_in = ""
                            let time_out = ""
                            let wrkhrs = ""
                            if (x[i].TIMEIN === null) {
                                time_in = "leave"
                            } else {
                                time_in = convertTimeFormat(x[i].TIMEIN)
                            }
                            if (x[i].TIMEOUT === null) {
                                time_out = "leave"
                            } else {
                                time_out = convertTimeFormat(x[i].TIMEOUT)
                            }
                            if (x[i].WORKHRS === null) {
                                wrkhrs = "No data"
                            } else {
                                wrkhrs = convertTimeFormat(x[i].WORKHRS)
                            }
                            table.row.add([count, x[i].ID, x[i].NAME, time_in, time_out, wrkhrs, x[i].DATE]).draw()
                        }
                    }, formdata)
                }
            })

            function convertTimeFormat(timeString) {
                const date = new Date(`2000-01-01T${timeString}`);
                const hours = date.getHours();
                const minutes = date.getMinutes();
                const seconds = date.getSeconds();
                const amPm = hours >= 12 ? 'PM' : 'AM';
                const twelveHour = hours % 12 || 12;
                const formattedTime = `${twelveHour.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')} ${amPm}`;
                return formattedTime;
            }
        }

        const manageEmployees = () => {
            $(document).ready(function() {
                $("#manage-employee").DataTable({
                    columnDefs: [{
                            width: '5%',
                            targets: 0
                        }, {
                            width: '10%',
                            targets: 1
                        },
                        {
                            width: '20%',
                            targets: 2
                        }, {
                            width: '13%',
                            targets: 3
                        }, {
                            width: '11%',
                            targets: 4
                        }, {
                            width: '15%',
                            targets: 5
                        }, {
                            width: '10%',
                            targets: 6
                        }, {
                            width: '22%',
                            targets: 7
                        }

                    ]
                });
            });

            loadEmployeeTbl()

            function loadEmployeeTbl() {
                userReq("GET", "assets/backend/showAllEmployee.php", (result) => {
                    var employee = $('#manage-employee').DataTable();
                    employee.clear().draw();
                    let x = JSON.parse(result)
                    let count = 0
                    for (let i = 0; i < x.length; i++) {
                        count++
                        let name = x[i].fname + ' ' + x[i].lname
                        let buttonsHtml = '<div class="btn-group">' +
                            '<button class="btn btn-primary viewBtn" data-toggle="modal" data-target="#detailsModal" data-id="' + x[i].ID + '"  data-gender="' + x[i].gender + '"  data-id="' + x[i].ID + '"  data-bday="' + x[i].bday + '"  data-email="' + x[i].email + '"  data-rate="' + x[i].posRate + '"  data-manager="' + x[i].manager + '"  data-datehired="' + x[i].datehired + '" data-managerName="' + x[i].managerName + '" "><i class="fas fa-eye"></i></button>' +
                            '<button class="btn btn-success editBtn" data-toggle="modal" data-target="#edit-employee" data-id="' + x[i].ID + '"  data-name="' + name + '"  data-position="' + x[i].posName + '" data-dept="' + x[i].dept + '" data-shift="' + x[i].shift + '" data-empType="' + x[i].empType + '" "><i class="fas fa-edit"></i> </button>'
                        '</div>'

                        employee.row.add([count, x[i].ID, name, x[i].posName, x[i].empType, x[i].dept, x[i].shift, buttonsHtml]).draw()
                    }
                    for (let y = 0; y < document.querySelectorAll(".viewBtn").length; y++) {
                        document.querySelectorAll(".viewBtn")[y].addEventListener("click", (e) => {

                            let gender = document.querySelectorAll(".viewBtn")[y].getAttribute("data-gender")
                            let bday = document.querySelectorAll(".viewBtn")[y].getAttribute("data-bday")
                            let email = document.querySelectorAll(".viewBtn")[y].getAttribute("data-email")
                            let rate = document.querySelectorAll(".viewBtn")[y].getAttribute("data-rate")
                            let manager = document.querySelectorAll(".viewBtn")[y].getAttribute("data-manager")
                            let datehired = document.querySelectorAll(".viewBtn")[y].getAttribute("data-datehired")
                            let managerName = document.querySelectorAll(".viewBtn")[y].getAttribute("data-managerName")
                            let mName = ""
                            console.log(datehired)
                            if (manager == String(null) || manager === null) {
                                document.querySelector("#managerdiv").style.display = "none"
                                mName = ""
                            } else {
                                mName = managerName
                                document.querySelector("#managerdiv").style.display = "block"
                            }
                            document.querySelector("#manager").innerHTML = mName
                            document.querySelector("#gender").innerHTML = gender
                            document.querySelector("#birthday").innerHTML = bday
                            document.querySelector("#email").innerHTML = email
                            document.querySelector("#rate").innerHTML = rate
                            document.querySelector("#datehired").innerHTML = datehired
                        })
                    }

                    for (let i = 0; i < document.querySelectorAll(".editBtn").length; i++) {
                        document.querySelectorAll(".editBtn")[i].addEventListener("click", (e) => {
                            document.querySelector("#employee-name").innerHTML = ""
                            document.querySelector("#update-employee").reset();
                            loadItems()
                            let id = document.querySelectorAll(".editBtn")[i].getAttribute("data-id")
                            let name = document.querySelectorAll(".editBtn")[i].getAttribute("data-name")
                            let position = document.querySelectorAll(".editBtn")[i].getAttribute("data-position")
                            let dept = document.querySelectorAll(".editBtn")[i].getAttribute("data-dept")
                            let shift = document.querySelectorAll(".editBtn")[i].getAttribute("data-shift")
                            let empType = document.querySelectorAll(".editBtn")[i].getAttribute("data-empType")


                            setTimeout(setData, 100)


                            function setData() {
                                document.querySelector("#employee-name").innerHTML = name + "  (" + id + ")"
                                document.querySelector("#employee-name").setAttribute("data-id", id)
                                document.querySelector("#list-position").value = document.querySelectorAll(".editBtn")[i].getAttribute("data-position")
                                document.querySelector("#list-employeetype").value = document.querySelectorAll(".editBtn")[i].getAttribute("data-empType")
                                document.querySelector("#list-department").value = document.querySelectorAll(".editBtn")[i].getAttribute("data-dept")
                                document.querySelector("#list-shift").value = document.querySelectorAll(".editBtn")[i].getAttribute("data-shift")
                            }
                        })
                    }

                    document.querySelector("#save-update-employee").addEventListener("click", () => {
                        let data = new FormData()
                        data.append("id", document.querySelector("#employee-name").getAttribute("data-id"))
                        let selectedPosition = document.querySelector("#list-position")
                        let selectedEmployeeType = document.querySelector("#list-employeetype")
                        let selectedDepartment = document.querySelector("#list-department")
                        let selectedShift = document.querySelector("#list-shift")
                        data.append("position", selectedPosition.options[selectedPosition.selectedIndex].dataset.id)
                        data.append("employeetype", selectedEmployeeType.options[selectedEmployeeType.selectedIndex].dataset.id)
                        data.append("department", selectedDepartment.options[selectedDepartment.selectedIndex].dataset.id)
                        data.append("shift", selectedShift.options[selectedShift.selectedIndex].dataset.id)
                        userReq("POST", "assets/backend/updatemgrEmployee.php", (result) => {
                            let x = JSON.parse(result)
                            if (!x.Error) {
                                swal("Success!", "Employee data has been changed", "success").then((result) => {
                                    if (result) {

                                        loadEmployeeTbl()
                                    } else {
                                        loadEmployeeTbl()
                                    }
                                    document.getElementById("edit-employee").style.display = "none"
                                    var modalBackdrop = document.getElementsByClassName("modal-backdrop")[0];
                                    modalBackdrop.parentNode.removeChild(modalBackdrop);
                                })
                            } else {
                                swal("Sorry!", "Something went wrong", "error")
                            }
                        }, data)
                    })

                    function loadItems() {
                        userReq("GET", "assets/backend/loaddropdown.php", (result) => {
                            let x = JSON.parse(result)
                            let position = document.querySelector("#list-position")
                            let emptype = document.querySelector("#list-employeetype")
                            let dept = document.querySelector("#list-department")
                            let shift = document.querySelector("#list-shift")
                            position.innerHTML = ""
                            emptype.innerHTML = ""
                            dept.innerHTML = ""
                            shift.innerHTML = ""
                            for (let i = 0; i < x[0].Department.length; i++) {
                                dept.innerHTML += '<option value="' + x[0].Department[i].Name + '" data-id="' + x[0].Department[i].ID + '" >' + x[0].Department[i].Name + '</option>'
                            }
                            for (let i = 0; i < x[1].WorkShift.length; i++) {
                                shift.innerHTML += '<option value="' + x[1].WorkShift[i].Name + '" data-id="' + x[1].WorkShift[i].ID + '">' + x[1].WorkShift[i].Name + '</option>'
                            }
                            for (let i = 0; i < x[2].EmploymentType.length; i++) {
                                emptype.innerHTML += '<option value="' + x[2].EmploymentType[i].Name + '" data-id="' + x[2].EmploymentType[i].ID + '">' + x[2].EmploymentType[i].Name + '</option>'
                            }
                            for (let i = 0; i < x[3].JobPosition.length; i++) {
                                position.innerHTML += '<option value="' + x[3].JobPosition[i].Name + '" data-id="' + x[3].JobPosition[i].ID + '">' + x[3].JobPosition[i].Name + '</option>'
                            }
                        })
                    }


                })
            }
        }


        const hireEmployees = () => {

            userReq("GET", "assets/backend/loaddropdown.php", (result) => {
                let x = JSON.parse(result)
                let dept = document.querySelector("#department")
                let emptype = document.querySelector("#employmenttype")
                let shift = document.querySelector("#shift")
                let position = document.querySelector("#position")
                let manager = document.querySelector("#manager")
                emptype.innerHTML = " <option value='' hidden>Select Employment Type</option>"
                dept.innerHTML = " <option value='' hidden>Select department</option>"
                shift.innerHTML = " <option value='' hidden>Select Workshift</option>"
                position.innerHTML = " <option value='' hidden>Select Job position</option>"
                manager.innerHTML = " <option value='' hidden>Select Manager</option>"
                for (let i = 0; i < x[0].Department.length; i++) {
                    dept.innerHTML += ' <option value="' + x[0].Department[i].ID + '">' + x[0].Department[i].Name + '</option>'

                }
                for (let i = 0; i < x[2].EmploymentType.length; i++) {
                    emptype.innerHTML += ' <option value="' + x[2].EmploymentType[i].ID + '">' + x[2].EmploymentType[i].Name + '</option>'
                }

                for (let i = 0; i < x[1].WorkShift.length; i++) {
                    shift.innerHTML += ' <option value="' + x[1].WorkShift[i].ID + '">' + x[1].WorkShift[i].Name + '</option>'
                }
                for (let i = 0; i < x[3].JobPosition.length; i++) {
                    position.innerHTML += ' <option value="' + x[3].JobPosition[i].Name + '" data-id="' + x[3].JobPosition[i].ID + '" >' + x[3].JobPosition[i].Name + '</option>'
                }
                for (let i = 0; i < x[4].Manager.length; i++) {
                    manager.innerHTML += ' <option value="' + x[4].Manager[i].ID + '">' + x[4].Manager[i].Name + '</option>'
                }
            })

            userReq("GET", "assets/backend/getApplicant.php", (result) => {
                let x = JSON.parse(result)
                let tbl = document.querySelector("#pending-tbl")
                tbl.innerHTML = ""
                let count = 0
                for (let i = 0; i < x.length; i++) {
                    count++
                    tbl.innerHTML += '<tr>' +
                        '<td>' + count + '</td>' +
                        '<td>' + x[i].name + '</td>' +
                        '<td>' +
                        '<button class="btn btn-primary btn-sync" data-name="' + x[i].name + '" data-fname="' + x[i].fname + '" data-mname="' + x[i].mname + '" data-lname="' + x[i].lname + '"data-webaccountid="' + x[i].webID + '" data-applicantid="' + x[i].applicantID + '" data-email="' + x[i].email + '" data-gender="' + x[i].gender + '" data-salary="' + x[i].salary + '" data-position="' + x[i].position + '" data-birthday="' + x[i].birthday + '">' +
                        '<i class="fas fa-edit"></i> Sync' +
                        '</button>' +
                        '</td>' +
                        '</tr>'
                }

                for (let i = 0; i < document.querySelectorAll(".btn-sync").length; i++) {
                    document.querySelectorAll(".btn-sync")[i].addEventListener("click", () => {
                        let name = document.querySelectorAll(".btn-sync")[i].getAttribute("data-name")
                        let fname = document.querySelectorAll(".btn-sync")[i].getAttribute("data-fname")
                        let mname = document.querySelectorAll(".btn-sync")[i].getAttribute("data-mname")
                        let lname = document.querySelectorAll(".btn-sync")[i].getAttribute("data-lname")
                        let gender = document.querySelectorAll(".btn-sync")[i].getAttribute("data-gender")
                        let birthday = document.querySelectorAll(".btn-sync")[i].getAttribute("data-birthday")
                        let email = document.querySelectorAll(".btn-sync")[i].getAttribute("data-email")
                        let salary = document.querySelectorAll(".btn-sync")[i].getAttribute("data-salary")
                        let webID = document.querySelectorAll(".btn-sync")[i].getAttribute("data-webaccountid")
                        let applicantID = document.querySelectorAll(".btn-sync")[i].getAttribute("data-applicantid")
                        let positions = document.querySelectorAll(".btn-sync")[i].getAttribute("data-position")

                        let formdata = new FormData(document.querySelector("#employeeform"))
                        document.querySelector("#submitEmployeeForm").setAttribute("data-id", applicantID)
                        document.querySelector("#submitEmployeeForm").setAttribute("data-fname", fname)
                        document.querySelector("#submitEmployeeForm").setAttribute("data-mname", mname)
                        document.querySelector("#submitEmployeeForm").setAttribute("data-lname", lname)
                        document.querySelector("#submitEmployeeForm").setAttribute("data-email", email)
                        document.querySelector("#name").value = name
                        document.querySelector("#gender").value = gender
                        document.querySelector("#birthday").value = birthday
                        document.querySelector("#email").value = email
                        document.querySelector("#rate").value = salary
                        document.getElementById("position").value = positions
                    })
                }


            })

            function EmployeeID(min, max) {
                return Math.floor(Math.random() * (max - min + 1)) + min;
            }

            function getCurrentDate() {
                const currentDate = new Date();
                const year = currentDate.getFullYear();
                const month = String(currentDate.getMonth() + 1).padStart(2, '0');
                const day = String(currentDate.getDate()).padStart(2, '0');
                const formattedDate = `${year}-${month}-${day}`;
                return formattedDate;
            }

            function addEmployees(data) {
                let formdata = new FormData(document.querySelector("#employeeform"))
                formdata.append("position", document.querySelector("#position").value)
                formdata.append("fname", document.querySelector("#submitEmployeeForm").getAttribute("data-fname"))
                formdata.append("mname", document.querySelector("#submitEmployeeForm").getAttribute("data-mname"))
                formdata.append("lname", document.querySelector("#submitEmployeeForm").getAttribute("data-lname"))
                formdata.append("applicantID", data)
                formdata.append("employeeID", EmployeeID(55555, 99999))
                formdata.append("date", getCurrentDate())
                if (formdata.get("manager").length === 0 || formdata.get("manager") === null || formdata.get("manager") === undefined) {
                    formdata.set("manager", "null")
                }
                if (formdata.get("department").length === 0 || formdata.get("position").length === 0 || formdata.get("employeetype").length === 0 || formdata.get("shift").length === 0) {
                    swal("Warning!", "Please fill out all fields", "warning")
                } else {
                    userReq("POST", "assets/backend/addEmployee.php", (result) => {
                        console.log(result, "ADDDD")
                        let x = JSON.parse(result)
                        if (x.Error) {
                            swal("Sorry!", "Something went wrong", "error")
                        } else {
                            swal("Success!", "Employee added successfully", "success").then((click) => {
                                document.querySelector("#submitEmployeeForm").removeAttribute("data-id")
                                let datas = new FormData()
                                datas.append("email", document.querySelector("#submitEmployeeForm").getAttribute("data-email"))
                                datas.append("msg", "Congratulations, You've Been Hired! \nCompany ID: " + formdata.get("employeeID") + "\n Pin:neocore\n Download Neo-Core application to change your pin\n\n\nThank you,\n-Dev | Zhen")
                                userReq("POST", "assets/backend/otp/adminmail.php", (result) => {
                                    console.log(result, "OTP")
                                    let x = JSON.parse(result)
                                    if (!x.Error) {
                                        swal("Success!", "Applicant has been informed via email", "success")
                                        document.querySelector("#employeeform").reset()
                                        hireEmployees()
                                    } else {
                                        swal("Error", "Something went wrong", "error")
                                    }
                                }, datas)

                            })
                        }
                    }, formdata)
                }

            }

            document.querySelector("#submitEmployeeForm").addEventListener("click", (e) => {
                e.preventDefault()
                let data = document.querySelector("#submitEmployeeForm").getAttribute("data-id")
                if (data == null) {
                    swal("Ooopss!", "Please sync employee first", "warning")
                } else {
                    swal({
                            title: "Are you sure?",
                            text: "",
                            icon: "warning",
                            buttons: {
                                cancel: true,
                                confirm: "Confirm"
                            }

                        })
                        .then((result) => {
                            if (result) {
                                addEmployees(data)
                            } else {

                            }
                        });
                }
            })
        }

        const JobOffer = () => {
            $(document).ready(function() {
                $("#jotbl").DataTable();
            });
            userReq("GET", "assets/backend/alljobs.php", (result) => {
                // let tbl = document.querySelector("#jo-tbl")
                // tbl.innerHTML = ""
                var jotable = $('#jotbl').DataTable();
                jotable.clear().draw();
                let x = JSON.parse(result);
                let count = 0
                for (let i = 0; i < x.length; i++) {
                    count++
                    let buttonsHtml = '<button type="button" class="btn btn-info btn-action edit-job" data-id="' + x[i].ID + '"' + 'data-toggle="modal"data-target="#jobModal">' +
                        '<i class="fas fa-pencil-alt"></i>' +
                        '</button>' +
                        '<button type="button" class="btn btn-danger btn-action delete-job" data-id="' + x[i].ID + '">' +
                        '<i class="fas fa-trash"></i>' +
                        '</button>'
                    jotable.row.add([count, x[i].TITLE, x[i].SALARY, x[i].LOCATION, buttonsHtml]).draw()
                }
                document.querySelector("#jobModals").addEventListener("click", () => {
                    loadPosition()
                    document.querySelector("#jobModalLabel").innerHTML = "Add Job"
                    document.querySelector("#addJob").style.display = "block"
                    document.querySelector("#updateJob").style.display = "none"
                    document.querySelector("#jobForm").reset()
                })
                const loadPosition = () => {
                    let position = document.querySelector("#modal-position")
                    position.innerHTML = ""
                    position.innerHTML = " <option hidden>Select Job position</option>"
                    userReq("GET", "assets/backend/loaddropdown.php", (result) => {
                        let x = JSON.parse(result)
                        for (let i = 0; i < x[3].JobPosition.length; i++) {
                            position.innerHTML += ' <option value="' + x[3].JobPosition[i].Name + '">' + x[3].JobPosition[i].Name + '</option>'
                        }
                    })
                }
                document.querySelector("#addJob").addEventListener("click", () => {
                    let data = new FormData(document.querySelector("#jobForm"))

                    if (data.get("position").length == 0 || data.get("desc").length == 0 || data.get("salary").length == 0 || data.get("location").length == 0) {
                        swal("Oopss!", "All input should be filled", "warning")
                    } else {
                        userReq("POST", "assets/backend/manageJO.php", (result) => {
                            let x = JSON.parse(result)
                            if (x.Error) {
                                swal("Sorry!", "Something went wrong", "error").then((result) => {
                                    JobOffer()
                                })
                            } else {
                                swal("Success!", "Job has been added", "success").then((result) => {
                                    document.querySelector("#jobForm").reset()
                                    document.getElementById("jobModal").style.display = "none"
                                    var modalBackdrop = document.getElementsByClassName("modal-backdrop")[0];
                                    modalBackdrop.parentNode.removeChild(modalBackdrop);
                                    JobOffer()

                                })

                            }
                        }, data)
                    }
                })

                for (let i = 0; i < document.querySelectorAll(".edit-job").length; i++) {
                    document.querySelectorAll(".edit-job")[i].addEventListener("click", (e) => {
                        let id = document.querySelectorAll(".edit-job")[i].getAttribute("data-id")
                        let data = new FormData()
                        data.append("id", id)
                        loadPosition()

                        userReq("POST", "assets/backend/getjobs.php", (result) => {
                            let x = JSON.parse(result)
                            document.querySelector("#jobModalLabel").innerHTML = "Update Job"
                            document.querySelector("[name='position']").value = x[0].TITLE
                            document.querySelector("#jobDescription").value = x[0].DESC
                            document.querySelector("#jobSalary").value = x[0].SALARY
                            document.querySelector("#jobLocation").value = x[0].LOCATION
                            document.querySelector("#addJob").style.display = "none"
                            document.querySelector("#updateJob").style.display = "block"
                            document.querySelector("#updateJob").setAttribute("data-uid", id)

                            document.querySelector("#updateJob").addEventListener("click", () => {
                                let formdata = new FormData(document.querySelector("#jobForm"))
                                formdata.append("id", document.querySelector("#updateJob").getAttribute("data-uid"))
                                if (formdata.get("position").length == 0 || formdata.get("desc").length == 0 || formdata.get("salary").length == 0 || formdata.get("location").length == 0) {
                                    swal("Oopss!", "All input should be filled", "warning")
                                } else {

                                    userReq("POST", "assets/backend/updatejo.php", (result) => {
                                        let value = JSON.parse(result)
                                        if (value.Error) {
                                            swal("Sorry!", "Something went wrong", "error")
                                        } else {
                                            swal("Success!", "Job has been updated", "success").then((result) => {
                                                document.querySelector("#jobForm").reset()
                                                document.getElementById("jobModal").style.display = "none"
                                                var modalBackdrop = document.getElementsByClassName("modal-backdrop")[0];
                                                modalBackdrop.parentNode.removeChild(modalBackdrop);
                                                JobOffer()

                                            })
                                        }
                                    }, formdata)
                                }

                            })
                        }, data)
                    })
                }

                for (let i = 0; i < document.querySelectorAll(".delete-job").length; i++) {
                    document.querySelectorAll(".delete-job")[i].addEventListener("click", () => {
                        let id = document.querySelectorAll(".edit-job")[i].getAttribute("data-id")
                        let formdata = new FormData()
                        formdata.append("id", id)
                        swal({
                                title: "Are you sure?",
                                text: "Do you want to delete this job",
                                icon: "warning",
                                buttons: {
                                    cancel: true,
                                    confirm: "Yes"
                                }

                            })
                            .then((result) => {
                                if (result) {
                                    userReq("POST", "assets/backend/deletejob.php", (result) => {
                                        let x = JSON.parse(result)
                                        if (x.Error) {
                                            swal("Sorry!", "Something went wrong", "error")
                                        } else {
                                            JobOffer()
                                            swal("Job has been deleted", {
                                                icon: "success",
                                            })
                                        }
                                    }, formdata)

                                } else {

                                }
                            });
                    })
                }
            })
        }

        const Applicant = () => {
            $(document).ready(function() {
                $("#applicanttbl").DataTable({
                    columnDefs: [{
                            width: '5%',
                            targets: 0
                        }, {
                            width: '25%',
                            targets: 1
                        },
                        {
                            width: '15%',
                            targets: 2
                        }, {
                            width: '10%',
                            targets: 3
                        }, {
                            width: '45%',
                            targets: 4
                        }
                    ]
                });
            });
            loadApplicantTbl()

            function loadApplicantTbl() {
                userReq("GET", "assets/backend/pendingapplicant.php", (result) => {
                    var applicantTable = $('#applicanttbl').DataTable();
                    applicantTable.clear().draw();
                    let x = JSON.parse(result)
                    let count = 0
                    // let tbl = document.querySelector("#tbl-content")
                    // tbl.innerHTML = ""
                    for (let i = 0; i < x.length; i++) {
                        count++
                        let element_link = "elem" + count
                        let name = x[i].fname + " " + x[i].lname
                        let buttonshtml = '<div class="btn-group">' +
                            '<button type="button" class="toggle btn btn-primary view-pic"  data-target="#' + element_link + '" data-link="' + x[i].img + '" data-linktype="' + x[i].imgtype + '">' +
                            '<i class="fas fa-image"></i>  Picture' +
                            '</button>' +
                            '<button type="button" class="toggle btn btn-success view-cv" data-id="' + x[i].id + '"  data-target="#' + element_link + '" data-link="' + x[i].cv + '"data-linktype="' + x[i].cvtype + '">' +
                            '<i class="fas fa-file-alt"></i>  CV' +
                            '</button>' +
                            '<button data-link="' + x[i].id + '"' +
                            'type="button"' +
                            'class=" btn btn-info view-requirement"' +
                            'data-toggle="collapse"' +
                            'data-target="#' + element_link + '">' +
                            '<i class="fa fa-list-alt"></i>  Requirements' +
                            '</button>' +
                            '</div>' +
                            '<div  class="collapse zhen" id="' + element_link + '">' +
                            '<ul id="require-list"> ' +
                            '</ul>' +
                            '</div>' +
                            '<div class="btn-group lastbtn">' +
                            '<button type="button" class="toggle btn btn-success accept-applicant" data-link="' + x[i].id + '"  data-target="#' + element_link + '">' +
                            '<i class="fas fa-check"></i> ' +
                            '</button>' +
                            '<button type="button" class="toggle btn btn-danger reject-applicant" data-link="' + x[i].id + '"  data-target="#' + element_link + '">' +
                            '<i class="fas fa-times"></i> ' +
                            '</button>' +
                            '</div>'
                        applicantTable.row.add([count, name, x[i].position, x[i].date, buttonshtml]).draw()

                    }



                    function downloadFile(base64Data, fileName) {
                        const link = document.createElement("a");
                        link.href = URL.createObjectURL(base64ToBlob(base64Data));
                        link.download = fileName;
                        link.click();
                    }

                    function base64ToBlob(base64Data) {
                        const byteString = atob(base64Data);
                        const buffer = new ArrayBuffer(byteString.length);
                        const array = new Uint8Array(buffer);
                        for (let i = 0; i < byteString.length; i++) {
                            array[i] = byteString.charCodeAt(i);
                        }
                        return new Blob([buffer], {
                            type: "application/octet-stream"
                        });
                    }

                    function getRotate() {
                        var currentRotation = 0;
                        document.getElementById("rotation").addEventListener("click", function() {
                            currentRotation += 90;
                            document.querySelector("#img-viewsource").style.transform = "rotate(" + currentRotation + "deg)";
                        });
                    }

                    function updateApplicant(status, id, msg) {
                        let formdata = new FormData()
                        formdata.append("id", id)
                        formdata.append("status", status)

                        userReq("POST", "assets/backend/updateApplicant.php", (result) => {
                            let x = JSON.parse(result)
                            if (x.Error) {
                                swal("Oh no!", "Sorry something went wrong", "error")
                            } else {
                                swal("Success!", "Applicant has been" + msg, "success").then((results) => {
                                    if (results) {
                                        loadApplicantTbl()
                                    } else {
                                        loadApplicantTbl()
                                    }
                                })
                            }
                        }, formdata)
                    }

                    for (let j = 0; j < document.querySelectorAll(".accept-applicant").length; j++) {
                        document.querySelectorAll(".accept-applicant")[j].addEventListener("click", () => {
                            let value = document.querySelectorAll(".accept-applicant")[j].getAttribute("data-link")
                            document.querySelector('.target-class')
                            swal({
                                    title: "Are you sure?",
                                    text: "",
                                    icon: "warning",
                                    buttons: {
                                        cancel: true,
                                        confirm: "Confirm"
                                    }

                                })
                                .then((result) => {
                                    if (result) {
                                        updateApplicant("accepted", value, "accepted")
                                        // swal("Gotcha!", {
                                        //     icon: "success",
                                        // }).then((result) => {
                                        //     if (result) {

                                        //     }
                                        // });
                                    } else {

                                    }
                                });

                        })
                    }

                    for (let j = 0; j < document.querySelectorAll(".reject-applicant").length; j++) {
                        document.querySelectorAll(".reject-applicant")[j].addEventListener("click", () => {
                            let value = document.querySelectorAll(".accept-applicant")[j].getAttribute("data-link")
                            swal({
                                    title: "Are you sure?",
                                    text: "",
                                    icon: "warning",
                                    buttons: {
                                        cancel: true,
                                        confirm: "Confirm"
                                    }

                                })
                                .then((result) => {
                                    if (result) {
                                        updateApplicant("rejected", value, "rejected")
                                        //     swal("Gotcha!", {
                                        //         icon: "success",
                                        //     }).then((result) => {
                                        //         if (result) {

                                        //         }
                                        //     });
                                    } else {

                                    }
                                });

                        })
                    }



                    for (let j = 0; j < document.querySelectorAll(".view-pic").length; j++) {
                        document.querySelectorAll(".view-pic")[j].addEventListener("click", () => {
                            let file = document.querySelectorAll(".view-pic")[j].getAttribute("data-link")
                            let linktype = document.querySelectorAll(".view-pic")[j].getAttribute("data-linktype")
                            document.querySelectorAll(".view-pic")[j].setAttribute("data-toggle", "modal")
                            document.querySelectorAll(".view-pic")[j].setAttribute("data-target", "#imagemodal")
                            let uri = "data:" + linktype + ";base64," + file
                            document.querySelector("#img-viewsource").src = uri
                            getRotate()
                        })
                    }

                    for (let j = 0; j < document.querySelectorAll(".view-cv").length; j++) {
                        document.querySelectorAll(".view-cv")[j].addEventListener("click", () => {
                            let file = document.querySelectorAll(".view-cv")[j].getAttribute("data-link")
                            let linktype = document.querySelectorAll(".view-cv")[j].getAttribute("data-linktype")
                            let link = document.querySelectorAll(".view-cv")[j].getAttribute("data-id")
                            let uri = "data:" + linktype + ";base64," + file
                            switch (linktype) {
                                case "application/pdf":
                                    window.open("fileviewer.php?id=" + link + "&key=assets/backend/viewrequirementscv.php", '_blank')
                                    break
                                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                                    swal({
                                            title: "Do you want to download instead?",
                                            text: "The file you're requested is MsWord",
                                            icon: "warning",
                                            buttons: {
                                                cancel: true,
                                                confirm: "Confirm"
                                            }

                                        })
                                        .then((result) => {
                                            if (result) {
                                                swal("Gotcha!", {
                                                    icon: "success",
                                                }).then((result) => {
                                                    if (result) {
                                                        downloadFile(file, "file.docx")
                                                    }
                                                });
                                            } else {

                                            }
                                        });
                                    break
                            }
                        })
                    }

                    for (let j = 0; j < document.querySelectorAll(".view-requirement").length; j++) {
                        document.querySelectorAll(".view-requirement")[j].addEventListener("click", () => {
                            // let datas = document.querySelectorAll(".toggle")[i].getAttribute("data-target")
                            // document.querySelector(datas).style.display = "block"
                            let req = document.querySelectorAll(".view-requirement")[j].getAttribute("data-link")
                            let data = new FormData()
                            data.append("ID", req)
                            let parent = document.querySelectorAll("#require-list")[j].parentNode
                            let requirement = document.querySelectorAll("#require-list")[j]
                            requirement.innerHTML = ""
                            userReq("POST", "assets/backend/showApplicantRequirements.php", (result) => {
                                let x = JSON.parse(result)
                                for (let i = 0; i < x.length; i++) {
                                    requirement.innerHTML += '<li class="app-list ms-5">' +
                                        '<a href="#" class="view-btn" data-link="' + x[i].attachment + '" data-linktype="' + x[i].attachmenttype + '" data-id="' + x[i].ID + '" >View</a>' +
                                        '</li>'
                                }


                                for (let k = 0; k < document.querySelectorAll(".view-btn").length; k++) {
                                    document.querySelectorAll(".view-btn")[k].addEventListener("click", () => {
                                        let file = document.querySelectorAll(".view-btn")[k].getAttribute("data-link")
                                        let link = document.querySelectorAll(".view-btn")[k].getAttribute("data-id")
                                        let linktype = document.querySelectorAll(".view-btn")[k].getAttribute("data-linktype")
                                        switch (linktype) {
                                            case "application/pdf":
                                                window.open("fileviewer.php?id=" + link + "&key=assets/backend/viewrequirements.php", '_blank')
                                                break
                                            case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                                                swal({
                                                        title: "Do you want to download instead?",
                                                        text: "The file you're requested is MsWord",
                                                        icon: "warning",
                                                        buttons: {
                                                            cancel: true,
                                                            confirm: "Confirm"
                                                        }

                                                    })
                                                    .then((result) => {
                                                        if (result) {
                                                            swal("Gotcha!", {
                                                                icon: "success",
                                                            }).then((result) => {
                                                                if (result) {
                                                                    downloadFile(file, "file.docx")
                                                                }
                                                            });
                                                        } else {

                                                        }
                                                    });
                                                break
                                            case "image/png":
                                            case "image/jpeg":
                                            case "image/jpg":
                                                document.querySelectorAll(".view-btn")[k].setAttribute("data-toggle", "modal")
                                                document.querySelectorAll(".view-btn")[k].setAttribute("data-target", "#imagemodal")
                                                let uri = "data:" + linktype + ";base64," + file
                                                document.querySelector("#img-viewsource").src = uri
                                                getRotate();
                                                break
                                        }
                                    })
                                }

                            }, data)
                        })
                    }
                })
            }
        }
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
</body>

</html>