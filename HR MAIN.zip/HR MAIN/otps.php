<!DOCTYPE html>
<html>

<head>
    <title>Submit Verification Code</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        body {
            background-color: #f1f1f1;
        }

        .container {
            margin-top: 50px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        input[type="text"] {
            text-align: center;
            font-size: 24px;
            border: none;
            border-bottom: 2px solid #ccc;
            margin: 0 10px;
            width: 50px;
            outline: none;
            padding: 10px;
            transition: border-bottom-color 0.3s ease;
        }

        input[type="text"]:focus {
            border-bottom-color: #007bff;
        }
    </style>
</head>

<body>
    <div class="container">
        <img src="images/Company-Logo.png" alt="">
        <h2 class="text-center">Enter Verification Code</h2>
        <form id="mform">
            <div class="form-group text-center">
                <input type="text" class="code" id="code1" name="code1" maxlength="1" required>
                <input type="text" class="code" id="code2" name="code2" maxlength="1" required>
                <input type="text" class="code" id="code3" name="code3" maxlength="1" required>
                <input type="text" class="code" id="code4" name="code4" maxlength="1" required>
                <input type="text" class="code" id="code5" name="code5" maxlength="1" required>
            </div>
            <!-- <div class="form-group text-center">
                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
            </div> -->
        </form>
    </div>
    <script src="assets/backend/main-scripting.js" type="module"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="module">
        import {
            codeReq
        } from "./assets/backend/main-scripting.js"
        import {
            userReq
        } from "./assets/backend/main-scripting.js"
        document.querySelector("#code1").focus()
        let userdata = new FormData()
        userdata.append("fname", sessionStorage.getItem("fname"))
        userdata.append("mname", sessionStorage.getItem("mname"))
        userdata.append("lname", sessionStorage.getItem("lname"))
        userdata.append("gender", sessionStorage.getItem("gender"))
        userdata.append("birthday", sessionStorage.getItem("birthday"))
        userdata.append("email", sessionStorage.getItem("email"))
        userdata.append("pass", sessionStorage.getItem("pass"))
        for (let i = 0; i < document.querySelectorAll(".code").length; i++) {
            document.querySelectorAll(".code")[i].addEventListener("input", () => {
                let add = 1
                if (i == 4) {
                    add = 0
                }
                document.querySelectorAll(".code")[i + add].focus()
                if (i == 4) {
                    console.log(i)
                    const form = document.getElementById("mform")
                    const data = new FormData(form)
                    var datainputted = data.get("code1") + data.get("code2") + data.get("code3") + data.get("code4") + data.get("code5")

                    if (datainputted == sessionStorage.getItem("OTP")) {
                        console.log("Matched")
                        userReq("POST", "assets/backend/createWebAccount.php", (result) => {
                            let value = JSON.parse(result)
                            if (value[0].Error) {
                                swal("Error", value[0].Message, "error")
                            } else {
                                swal(value[0].Message, "You may now login", "success").then((result) => {
                                    if (result) {
                                        sessionStorage.clear()
                                        window.location.href = "form.php"
                                    } else {
                                        sessionStorage.clear()
                                        window.location.href = "form.php"
                                    }
                                })
                            }
                        }, userdata)
                    } else {
                        // console.log("Not Matched")
                        swal("Incorrect Code", "", "error").then((result) => {
                            if (result) {
                                form.reset()
                                document.querySelector("#code1").focus()
                            } else {
                                form.reset()
                                document.querySelector("#code1").focus()
                            }
                        })
                    }
                }
            })
        }
    </script>
</body>

</html>